# meta luna

- init conda environment

```
conda create --name ds python=3.6.6

source activate ds
```

- install postgresql 9.6 from enterprise db


```
# superuser
postgres:pg0831gq

/Library/PostgreSQL/9.6/bin/psql

# create user for django
> CREATE USER yg WITH PASSWORD 'i0714@NUC' CREATEDB CREATEUSER;

> CREATE DATABASE ds_site;

> GRANT ALL PRIVILEGES ON DATABASE ds_site TO yg;
```

```
pip install django

pip install djangorestframework
pip install django-cors-headers
pip install markdown
pip install django-filter
pip install django-extensions
pip install psycopg2

pip install numpy
pip install scipy
```

- run

```
python manage.py shell < backend/plugins/optimizers_test.py
```

```
python manage.py runserver

# check
http://127.0.0.1:8000/
```

