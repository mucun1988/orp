"""Initiate store, skus and ledgers.
Author: yg <gyang274@gmail.com>

python manage.py shell < backend/plugins/initiators_test.py
"""

import numpy as np

from backend.models import Store, Sku, Event, Ledger
from backend.serializers import StoreSerializer, SkuSerializer, EventSerializer, LedgerSerializer

from backend.plugins import initiators
from backend.plugins.utilities import view_store_skus_ledgers

payload = initiators.payload_defaults

store, skus, ledgers = initiators.initiate_store_ledger(payload)

view_store_skus_ledgers(payload['tag'], day=0)

