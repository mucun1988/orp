import logging
import sys

logger = logging.getLogger('METALUNA')

_logging_target = sys.stdout
_handler = logging.StreamHandler(_logging_target)
_handler.setFormatter(
  logging.Formatter(
    fmt='%(asctime)s|%(levelname)s|%(name)s|%(filename)s|LINE:%(lineno)s|%(funcName)s|%(message)s',
    # datefmt='%Y-%m-%d %H:%M:%S',
  )
)

logger.addHandler(_handler)

logger.setLevel(level='INFO')
