"""Resolve events over ledger.
Author: yg <gyang274@gmail.com>
"""

import numpy as np

from functools import partial

from django.db import transaction

from backend.models import Store, Sku, Event, Ledger, Cache

from .logger import logger

from .utilities import get_resolver_view
from .utilities import set_instance, set_ledger_random_seed


def _resolve_event_with_action_none(event, ledger):
  set_instance(event, {'status': Event.STATUS_NN}, reset=False)


def _resolve_event_with_action_receive(event, ledger):
  """action on receive: units distribute to shelf, top, and back.
  """

  assert event.units > 0, 'Zero or Negative Units Receive'

  with transaction.atomic():
    try:
      units = event.units
      # receive: 1st receive to shelf, receive by size
      sfunits = min(units, ledger.sfw)
      expense = event.sku.store.rvar * np.ceil(units / event.sku.size)
      set_instance(event, {
        'units': sfunits,
        'target': Event.SRCTRG_SF,
        'expense': expense,
        'status': Event.STATUS_OK,
      }, reset=False)
      set_instance(ledger, {
        'sfu': ledger.sfu + sfunits,
        'sfx': sfunits,
        'rex': ledger.rex + expense,
      }, reset=False)
      units = units - sfunits
      if units > 0:
        # receive: 2nd receive to top
        tpunits = min(units, ledger.tpw)
        expense = event.sku.store.mvst * tpunits
        set_instance(event, {
          'units': tpunits,
          'source': Event.SRCTRG_SF,
          'target': Event.SRCTRG_TP,
          'expense': expense,
          'status': Event.STATUS_OK,
        }, reset=True)
        set_instance(ledger, {
          'tpu': ledger.tpu + tpunits,
          'tpx': tpunits,
          'mex': ledger.mex + expense,
        }, reset=False)
        units = units - tpunits
        if units > 0:
          # receive: 3rd receive to back
          bkunits = units # min(units, ledger.bkw)
          expense = event.sku.store.mvfb * np.ceil(bkunits / event.sku.size)
          set_instance(event, {
            'units': units,
            'source': Event.SRCTRG_TP,
            'target': Event.SRCTRG_BK,
            'expense': expense,
            'status': Event.STATUS_OK,
          }, reset=True)
          set_instance(ledger, {
            'bku': ledger.bku + units,
            'bkx': bkunits,
            'mex': ledger.mex + expense,
          }, reset=False)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_scan(event, ledger):

  assert event.units > 0, 'Zero or Negative Units Scan'

  with transaction.atomic():
    try:
      units = event.units
      expense = event.sku.store.svar * np.ceil(units / event.sku.size)
      set_instance(event, {
        'source': Event.SRCTRG_NN,
        'target': Event.SRCTRG_BK,
        'expense': expense,
        'status': Event.STATUS_OK,
      }, reset=False)
      set_instance(ledger, {
        'sex': ledger.sex + expense,
      }, reset=False)
      if ledger.sfw > 0:
        set_instance(event, {
          'action': Event.ACTION_MV,
          'source': Event.SRCTRG_BK,
        }, reset=True)
        _resolve_event_with_action_move_src_back(event, ledger)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_move_src_top(event, ledger):

  with transaction.atomic():
    try:
      units = min(ledger.tpu, ledger.sfw)
      # move: 1st move to shelf
      sfunits = min(units, ledger.sfw)
      expense = event.sku.store.mvts * sfunits
      set_instance(event, {
        'units': sfunits,
        'source': Event.SRCTRG_TP,
        'target': Event.SRCTRG_SF,
        'expense': expense,
        'status': Event.STATUS_OK,
      }, reset=False)
      set_instance(ledger, {
        'sfu': ledger.sfu + sfunits,
        'tpu': ledger.tpu - sfunits,
        'mex': ledger.mex + expense,
      }, reset=False)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _get_units_source_back_target_shelf(ledger):

  bkpks, bkres = ledger.bku // ledger.sku.size, ledger.bku % ledger.sku.size
  sfpks, sfres = ledger.sfw // ledger.sku.size, ledger.sfw % ledger.sku.size

  if sfpks > bkpks:
    units = ledger.bku
  elif sfpks == bkpks:
    units = sfpks * ledger.sku.size + min(sfres, bkres)
  else:
    if sfres > bkres:
      units = (sfpks + 1) * ledger.sku.size
    else:
      units = sfpks * ledger.sku.size + sfres

  return units


def _resolve_event_with_action_move_src_back(event, ledger):

  with transaction.atomic():
    try:
      units = _get_units_source_back_target_shelf(ledger)
      # move: 1st move to shelf, move by size
      sfunits = min(units, ledger.sfw)
      expense = event.sku.store.mvbf * np.ceil(units / event.sku.size)
      set_instance(event, {
        'units': sfunits,
        'source': Event.SRCTRG_BK,
        'target': Event.SRCTRG_SF,
        'expense': expense,
        'status': Event.STATUS_OK,
      }, reset=False)
      set_instance(ledger, {
        'sfu': ledger.sfu + sfunits,
        'bku': ledger.bku - sfunits,
        'mex': ledger.mex + expense,
      }, reset=False)
      units = units - sfunits
      if units > 0:
        # move: 2nd move to top
        tpunits = min(units, ledger.tpw)
        expense = event.sku.store.mvst * tpunits
        set_instance(event, {
          'units': tpunits,
          'source': Event.SRCTRG_SF,
          'target': Event.SRCTRG_TP,
          'expense': expense,
          'status': Event.STATUS_OK,
        }, reset=True)
        set_instance(ledger, {
          'tpu': ledger.tpu + tpunits,
          'bku': ledger.bku - tpunits,
          'mex': ledger.mex + expense,
        }, reset=False)
        units = units - tpunits
      if units > 0:
        # move: 3rd move back to back
        expense = event.sku.store.mvfb * np.ceil(units / event.sku.size)
        set_instance(event, {
          'units': units,
          'source': Event.SRCTRG_TP,
          'target': Event.SRCTRG_BK,
          'expense': expense,
          'status': Event.STATUS_OK,
        }, reset=True)
        set_instance(ledger, {
          'mex': ledger.mex + expense,
        }, reset=False)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_move(event, ledger):
  """action on move: move units within shelf, top, and back.
  """

  with transaction.atomic():
    try:
      if event.source == Event.SRCTRG_BK:
        _resolve_event_with_action_move_src_back(event, ledger)
      elif event.source == Event.SRCTRG_TP:
        _resolve_event_with_action_move_src_top(event, ledger)
      else:
        move_src_back = 0
        if ledger.bku > 0 and ledger.sfw + ledger.tpw > 0:
          move_src_back = 1
          _resolve_event_with_action_move_src_back(event, ledger)
        if ledger.tpu > 0 and ledger.sfw > 0:
          if move_src_back == 1:
            set_instance(event, {}, reset=True)
          _resolve_event_with_action_move_src_top(event, ledger)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_sell(event, ledger, auto_move=True):
  """action on sell: sell units from shelf, top, and back.

  Args:
    auto_move: auto move units from back to shelf and top when no front stock to resolve sell.

  # CFA: General Principles of Expense Recognition
      # Matching principle: recognize expenses whenever the associated revenues are recognized,
      # thereby matching expenses and revenues, gross profit = (sku.urvn - sku.urvc) * sfunits.
  """

  assert event.units >= 0, 'Negative Units Sell'

  with transaction.atomic():
    try:
      units = event.units
      if units > 0 and ledger.sfu > 0:
        sfunits = min(units, ledger.sfu)
        rrevenue = event.sku.urvn * sfunits
        crevenue = event.sku.urvc * sfunits
        mrevenue = rrevenue - crevenue
        set_instance(event, {
          'units': sfunits,
          'source': Event.SRCTRG_SF,
          'revenue': mrevenue,
          'status': Event.STATUS_OK,
        }, reset=False)
        set_instance(ledger, {
          'ask': ledger.ask + sfunits,
          'sun': ledger.sun + sfunits,
          'sfu': ledger.sfu - sfunits,
          'rvn': ledger.rvn + rrevenue,
          'rvc': ledger.rvc + crevenue,
        }, reset=False)
        units = units - sfunits
        if units > 0 and ledger.tpu > 0:
          tpunits = min(units, ledger.tpu)
          set_instance(event, {
            'action': Event.ACTION_MV,
            'source': Event.SRCTRG_TP,
            'units': tpunits,
            'status': Event.STATUS_QU,
          }, reset=True)
          _resolve_event_with_action_move_src_top(event, ledger)
          set_instance(event, {
            'action': Event.ACTION_SL,
            'source': Event.SRCTRG_SF,
            'units': tpunits,
            'status': Event.STATUS_QU,
          }, reset=True)
          _resolve_event_with_action_sell(event, ledger, auto_move)
          units = units - tpunits
        if units > 0 and ledger.bku > 0 and auto_move:
          bkunits = min(units, ledger.bku)
          set_instance(event, {
            'action': Event.ACTION_MV,
            'source': Event.SRCTRG_BK,
            'units': bkunits,
            'status': Event.STATUS_QU,
          }, reset=True)
          _resolve_event_with_action_move_src_back(event, ledger)
          set_instance(event, {
            'action': Event.ACTION_SL,
            'source': Event.SRCTRG_SF,
            'units': bkunits,
            'status': Event.STATUS_QU,
          }, reset=True)
          _resolve_event_with_action_sell(event, ledger, auto_move)
          units = units - bkunits
      if units > 0:
        orevenue = event.sku.urvm * units
        set_instance(event, {
          'action': Event.ACTION_SL,
          'source': Event.SRCTRG_SF,
          'units': units,
          'revenue': orevenue,
          'status': Event.STATUS_MS,
        }, reset=True)
        set_instance(ledger, {
          'ask': ledger.ask + units,
          'rvo': ledger.rvo + orevenue,
        }, reset=False)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_order(event, ledger, random_seed):
  """action on order: an event receive in the future w.r.t ordays and orprob.
  """

  assert event.units > 0, 'Zero or Negative Units Order'

  with transaction.atomic():
    try:
      orunits = np.ceil(event.units / event.sku.size) * event.sku.size
      np.random.seed(set_ledger_random_seed(ledger, random_seed))
      ordays = np.random.choice(event.sku.ordays, size=1, p=event.sku.orprob)[0]
      expense = event.sku.orgvar * orunits * event.sku.volume
      set_instance(event, {
        'expense': expense,
        'status': Event.STATUS_OK
      }, reset=False)
      set_instance(event, {
        'day': event.day + ordays,
        'action': Event.ACTION_RC,
        'source': Event.SRCTRG_NN,
        'target': Event.SRCTRG_NN,
        'units': orunits,
        'status': Event.STATUS_QU,
      }, reset=True)
      set_instance(ledger, {
        'oun': ledger.oun + orunits,
        'oex': ledger.oex + expense,
      }, reset=False)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_express(event, ledger, random_seed):
  """action on express: an event receive in the future w.r.t xrdays and xrprob.
  """

  assert event.units > 0, 'Zero or Negative Units Express'

  with transaction.atomic():
    try:
      xrunits = event.units
      np.random.seed(set_ledger_random_seed(ledger, random_seed))
      xrdays = np.random.choice(event.sku.xrdays, size=1, p=event.sku.xrprob)[0]
      expense = event.sku.xrgvar * xrunits * event.sku.volume
      set_instance(event, {
        'expense': expense,
        'status': Event.STATUS_OK
      }, reset=False)
      set_instance(event, {
        'day': event.day + xrdays,
        'action': Event.ACTION_RC,
        'source': Event.SRCTRG_NN,
        'target': Event.SRCTRG_NN,
        'units': xrunits,
        'status': Event.STATUS_QU,
      }, reset=True)
      set_instance(ledger, {
        'xun': ledger.xun + xrunits,
        'xex': ledger.xex + expense,
      }, reset=False)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_holding(event, ledger):
  """action on holding: holding cost w.r.t capital and volumes.
  """

  with transaction.atomic():
    try:
      # holding cost w.r.t capital
      cexpense = event.sku.store.cvar * (ledger.sfu + ledger.tpu + ledger.bku) * event.sku.urvc
      # holding cost w.r.t volumes
      vexpense = event.sku.store.vvar * (ledger.tpu + ledger.bku) * event.sku.volume
      set_instance(event, {
        'units': ledger.sfu + ledger.tpu + ledger.bku,
        'expense': cexpense + vexpense,
        'status': Event.STATUS_OK
      }, reset=False)
      set_instance(ledger, {
        'cex': ledger.cex + cexpense,
        'vex': ledger.rex + vexpense,
      }, reset=False)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _resolve_event_with_action_unknown(event, ledger):
  set_instance(event, {'status': Event.STATUS_UN}, reset=False)


def resolve_events_over_store_ledger(tag, day, random_seed):
  """resolve one day events over store skus ledgers.
  """
  store, skus, ledgers, gevents = get_resolver_view(tag, day)

  for ledger in ledgers:
    events = gevents.filter(sku=ledger.sku)
    for event in events:
      if event.action == Event.ACTION_NN:
        _resolve_event_with_action_none(event, ledger)
      elif event.action == Event.ACTION_RC:
        _resolve_event_with_action_receive(event, ledger)
      elif event.action == Event.ACTION_SC:
        _resolve_event_with_action_scan(event, ledger)
      elif event.action == Event.ACTION_MV:
        _resolve_event_with_action_move(event, ledger)
      elif event.action == Event.ACTION_SL:
        _resolve_event_with_action_sell(event, ledger)
      elif event.action == Event.ACTION_OR:
        _resolve_event_with_action_order(event, ledger, random_seed)
      elif event.action == Event.ACTION_XR:
        _resolve_event_with_action_express(event, ledger, random_seed)
      elif event.action == Event.ACTION_HD:
        _resolve_event_with_action_holding(event, ledger)
      else:
        _resolve_event_with_action_unknown(event, ledger)

  return None


resolver_defaults = resolve_events_over_store_ledger
