"""Trigger events from legder.
Author: yg <gyang274@gmail.com>
"""

import numpy as np

from scipy import optimize, stats

from functools import partial

from django.db import transaction

from backend.models import Store, Sku, Event, Ledger, Cache

from .logger import logger

from .utilities import get_triggerr_view
from .utilities import set_instance, set_ledger_random_seed


def _get_units_sell_from_gaussian(ledger, random_seed):
  """get units sell.

  Args:
    sku.asksmn: asks mean
    sku.askssd: asks standard deviation

  Generate one random number w.r.t guassian (sku.asksmn, sku.askssd).
  """

  np.random.seed(set_ledger_random_seed(ledger, random_seed))
  units = max(0, int(np.random.normal(ledger.sku.asksmn, ledger.sku.askssd, 1)[0]))

  return units


def _get_rpoos_series(x, mn, sd, days, receives):
  """get the receive oos probability series.

  :param:
    x: units on hand
    mn: daily demand mean
    sd: daily demand standard deviation
    days: list of days, might not successive, e.g., (5, 7, 8)
      days are receive days, e.g., event day - 1, and this is the reason to use d + 2,
      since want to calculate oos probability for the end of day, e.g., event day + 1.
    receives: list of receives between > d - 1 and <= d, respectively

  :return:
    ooss: a list of len(days), marginal probability of oos.
  """

  return [
    stats.norm.sf(
      x + r, loc=(d + 2) * mn, scale=np.sqrt(d + 2) * sd
    ) for d, r in zip(
      days, receives
    )
  ]


def _get_units_want_from_gaussian(rdays, rprob, alpha, rgday, rgprb, ledger, revents):
  """get units want.

  :param:
    rdays: sku.ordays, or sku.xrdays
      match between days:
        event receive days: 0, 1, 2, 3, ...
        order receive days:  , 0, 1, 2, ...
      since this is triggering order for next day
    rprob: sku.orprob, or sku.xrprob
    alpha: sku.orpoos, or sku.xrpoos
    rgday: sku.orgday, or sku.xrgday
    rgprb: sku.orgprb, or sku.xrgprb

  :return
    units: number of units to order
    dprob: desperate probability, e.g., probability s.t. oos before min sku.ordays.
  """

  # insert a dday, e.g., desperate day, day before minimum sku.ordays or sku.xrdays,
  # a.k.a, going to oos if units on hand are not enough, no matter how fast deliver.
  days = [min(rdays) - 1] + rdays

  receives = [0] * len(days)

  for event in revents:
    if event.action == Event.ACTION_RC:
        rday = event.day - ledger.day - 1
        for idx, day in enumerate(days):
          if (idx == 0 or rday > days[idx - 1]) and rday <= days[idx]:
            receives[idx] += event.units

  receives = np.cumsum(receives)

  rpoos_days = _get_rpoos_series(
    ledger.smu, ledger.sku.asksmn, ledger.sku.askssd, days, receives
  )

  dprob = rpoos_days[0]

  # weight sum of rpoos over days
  rpoos_wsum = 0
  for idx, rpoos in enumerate(rpoos_days):
    if idx > 0:
      if idx == 1:
        # probability of out of stock before and on min(rdays), rdays[0], weighted on deliver today.
        rpoos_wsum += rpoos_days[idx] * rprob[idx - 1]
      else: # idx > 1
        # probability of out of stock on rdays[1:], condition on previous day in stock, weighted on deliver today.
        rpoos_wsum += (1.00 - rpoos_days[idx - 1]) * rpoos_days[idx] * rprob[idx - 1]


  units = 0
  if rpoos_wsum >= alpha:
    # order to target rgday stock
    units = stats.norm.ppf(
      rgprb, loc=rgday * ledger.sku.asksmn, scale=np.sqrt(rgday) * ledger.sku.askssd
    )
    units = units - ledger.smu
    for event in revents:
      if event.action == Event.ACTION_RC:
        rday = event.day - ledger.day - 1
        if rday < rgday:
          units = units - event.units

    units = max(0, units)

  return units, dprob


def _get_units_order_from_gaussian(ledger, revents):
  return _get_units_want_from_gaussian(
    rdays=ledger.sku.ordays,
    rprob=ledger.sku.orprob,
    alpha=ledger.sku.orpoos,
    rgday=ledger.sku.orgday,
    rgprb=ledger.sku.orgprb,
    ledger=ledger,
    revents=revents,
  )


def _get_units_express_from_gaussian(ledger, revents):
  return _get_units_want_from_gaussian(
    rdays=ledger.sku.xrdays,
    rprob=ledger.sku.xrprob,
    alpha=ledger.sku.xrpoos,
    rgday=ledger.sku.xrgday,
    rgprb=ledger.sku.xrgprb,
    ledger=ledger,
    revents=revents,
  )


def _trigger_event_with_action_scan(ledger):

  with transaction.atomic():
    try:
      units = ledger.bku
      if units > 0:
        event = Event.objects.create(
          sku=ledger.sku,
          day=ledger.day,
          action=Event.ACTION_SC,
          source=Event.SRCTRG_NN,
          target=Event.SRCTRG_BK,
          units=units,
          status=Event.STATUS_QU,
        )
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _trigger_event_with_action_sell(ledger, random_seed):

  with transaction.atomic():
    try:
      units = _get_units_sell_from_gaussian(ledger, random_seed)
      if units >= 0:
        event = Event.objects.create(
          sku=ledger.sku,
          day=ledger.day,
          action=Event.ACTION_SL,
          source=Event.SRCTRG_SF,
          target=Event.SRCTRG_NN,
          units=units,
          status=Event.STATUS_QU,
        )
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _trigger_event_with_action_order(ledger, revents):

  with transaction.atomic():
    try:
      # optimizer requires allow sfcols=0 to see what revenue miss when delete
      if ledger.sku.sfcols > 0:
        units, dprob = _get_units_order_from_gaussian(ledger, revents)
        if units > 0:
          units = np.ceil(units / ledger.sku.size) * ledger.sku.size
          event = Event.objects.create(
            sku=ledger.sku,
            day=ledger.day + 1,
            action=Event.ACTION_OR,
            units=units
          )
        if dprob > ledger.sku.xrpoos and ledger.sku.orgxrg:
          _trigger_event_with_action_express(ledger, revents)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _trigger_event_with_action_express(ledger, revents):

  with transaction.atomic():
    try:
      if ledger.sku.sfcols > 0:
        units, dprob = _get_units_express_from_gaussian(ledger, revents)
        if units > 0:
          units = np.ceil(units / ledger.sku.size) * ledger.sku.size
          event = Event.objects.create(
            sku=ledger.sku,
            day=ledger.day + 1,
            action=Event.ACTION_XR,
            units=units
          )
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def _trigger_event_with_action_holding(ledger):

  with transaction.atomic():
    try:
      event = Event.objects.create(
        sku=ledger.sku,
        day=ledger.day,
        action=Event.ACTION_HD,
        status=Event.STATUS_QU,
      )
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


def trigger_events_from_store_ledger(tag, day, random_seed):
  """trigger_events_from_store_ledger
  :param
    su_express: bool, enable express or not
    random_seed: int, random seed on generating sell events
  """

  store, skus, ledgers, fevents = get_triggerr_view(tag, day)

  for ledger in ledgers:

    revents = fevents.filter(sku=ledger.sku)

    _trigger_event_with_action_scan(ledger)

    _trigger_event_with_action_sell(ledger, random_seed)

    _trigger_event_with_action_order(ledger, revents)

    _trigger_event_with_action_holding(ledger)

  return None


triggerr_defaults = trigger_events_from_store_ledger


