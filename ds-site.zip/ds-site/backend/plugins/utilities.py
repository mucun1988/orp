"""Utilities: miscellaeous functions.
Author: yg <gyang274@gmail.com>
"""

import json

from django.core.exceptions import ObjectDoesNotExist

from rest_framework import serializers

from backend.models import Store, Sku, Event, Ledger, Cache
from backend.serializers import StoreSerializer, SkuSerializer, EventSerializer, LedgerSerializer, CacheSerializer

from .logger import logger


class Status(object):
  STATUS_OK = 0
  STATUS_FX = 1


def set_instance(instance, payload, reset: bool):
  if reset: instance.pk = None
  for field in payload.keys():
    # instance.__dict__[field] = payload[field]
    instance.__setattr__(field, payload[field])
  instance.save()


def view_instance(instance):
  if isinstance(instance, Store):
    instance_src = 'Store'
    instance_serializer = StoreSerializer(instance)
  elif isinstance(instance, Sku):
    instance_src = 'Sku'
    instance_serializer = SkuSerializer(instance)
  elif isinstance(instance, Event):
    instance_src = 'Event'
    instance_serializer = EventSerializer(instance)
  elif isinstance(instance, Ledger):
    instance_src = 'Ledger'
    instance_serializer = LedgerSerializer(instance)
  elif isinstance(instance, Cache):
    instance_src = 'Cache'
    instance_serializer = CacheSerializer(instance)
  else:
    instance_src = 'Unknown'
    instance_serializer = serializers.Serializer(instance)
  print('{}: {}'.format(instance_src, json.dumps(instance_serializer.data, indent=2)))


def set_ledger_next_day(ledger, day=1):
  set_instance(ledger, {
    'day': ledger.day + day,
    'ask': 0,
    'sfx': 0,
    'tpx': 0,
    'bkx': 0,
    'sun': 0,
    'oun': 0,
    'xun': 0,
    'rex': 0.00,
    'sex': 0.00,
    'mex': 0.00,
    'oex': 0.00,
    'xex': 0.00,
    'cex': 0.00,
    'vex': 0.00,
    'rvn': 0.00,
    'rvc': 0.00,
    'rvo': 0.00,
  }, reset=True)


def get_store_skus_ledgers(tag, day):
  assert day >= 0, 'Negative Day'
  # store
  store = Store.objects.get(tag=tag)
  # skus w.r.t stores
  skus = Sku.objects.filter(store=store)
  # ledgers w.r.t skus
  ledgers = []
  for sku in skus:
    try:
      ledger = Ledger.objects.get(sku=sku, day=day)
    except ObjectDoesNotExist:
      if day == 0:
        logger.error('Ledger access w.o. init.')
      ledger = Ledger.objects.get(sku=sku, day=day - 1)
      set_ledger_next_day(ledger)
    ledgers.append(ledger)
  return store, skus, ledgers


def get_triggerr_view(tag, day):
  store, skus, ledgers = get_store_skus_ledgers(tag, day)
  fevents = Event.objects.filter(
    sku__in=skus, day__gt=day, action=Event.ACTION_RC, status=Event.STATUS_QU
  ).order_by('sku', 'day')
  return store, skus, ledgers, fevents


def get_resolver_view(tag, day):
  store, skus, ledgers = get_store_skus_ledgers(tag, day)
  gevents = Event.objects.filter(
    sku__in=skus, day=day, status=Event.STATUS_QU
  ).order_by('sku', 'action')
  return store, skus, ledgers, gevents


def view_store_skus_ledgers(tag, day):
  store, skus, ledgers = get_store_skus_ledgers(tag, day)
  view_instance(store)
  for sku in skus:
    view_instance(sku)
  for ledger in ledgers:
    view_instance(ledger)


def set_ledger_random_seed(ledger, random_seed):
  """random seed w.r.t sku tag and day, control repeatness in optmizer
    w.r.t. randomness in resolver: order, express, and triggerr: sell.
  """
  if random_seed == 0:
    ledger_random_seed = int(ledger.sku.gtag) + ledger.day
  else:
    ledger_random_seed = random_seed + ledger.day
  return ledger_random_seed