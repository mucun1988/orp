"""Operate store w.r.t event and create ledger.
Author: yg <gyang274@gmail.com>
"""

from .logger import logger


def operate_store(tag, day, days, resolver, triggerr, random_seed):

  for iday in range(day, day + days):
    # resolve events such as receive, order, and express from previous days.
    logger.info('{}|Resolve Day: {}'.format(tag, iday))
    resolver(tag, iday, random_seed)
    # trigger events such as scan and sell in current day, order and express in next day.
    logger.info('{}|Trigger Day: {}'.format(tag, iday))
    triggerr(tag, iday, random_seed)
    # resolve events such as scan, move, sell, and holding.
    logger.info('{}|Resolve Day: {}'.format(tag, iday))
    resolver(tag, iday, random_seed)

  return None


operator_defaults = operate_store


class Manager(object):

  def __init__(self, tag, day, payload, initiator, resolver, triggerr, random_seed, operator, viewer):

    self.tag = tag
    self.day = day
    self.payload = payload
    self.initiator = initiator
    self.resolver = resolver
    self.triggerr = triggerr
    self.random_seed = random_seed
    self.operator = operator
    self.viewer = viewer

  def initiate(self):
    self.initiator(self.payload)

  def operates(self, days):
    self.operator(self.tag, self.day, days, self.resolver, self.triggerr, self.random_seed)

  def set_view(self):
    self.viewer(self.tag)

  def set_days(self, days):
    self.day = self.day + days

  def run(self, days):
    self.initiate()
    self.operates(days=days)
    self.set_view()
    self.set_days(days=days)

