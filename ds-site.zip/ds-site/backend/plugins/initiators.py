"""Initiate store, skus and ledgers.
Author: yg <gyang274@gmail.com>
"""

import numpy as np

from django.db import transaction

from backend.models import Store, Sku, Event, Ledger, Cache

from .logger import logger


payload_defaults = {
  # store
  "tag": "ML00",
  "name": "Meta Luna Run 0x00",
  # store expense structure
  # receive variable cost by pack
  # $14/hr / 48 packs per hour
  "rvar": 0.2917,
  # scan variable cost by pack
  # $14/hr / 96 packs per hour
  "svar": 0.1458,
  # holding capital cost by dollar
  # $1 * 0.10 / 365
  "cvar": 0.0002740,
  # holding space cost by Ft^3
  # $231452/month rent / 30 days / 148000 Ft^2 / 16 Ft height
  "vvar": 0.0032581,
  # move variable cost between shelf and top by unit
  # $14 / 40|24 units per hour
  "mvst": 0.3500,
  "mvts": 0.5834,
  # move variable cost between front and backroom by pack
  # $14 / 10|6 packs per hour
  "mvbf": 1.4000,
  "mvfb": 2.3334,
  "info": {
    "transportation": {
      "ass": {
        "name": "assembly distribution center",
        "ordays": [10, 11, 12, 13, 14],
        "orprob": [0.10, 0.10, 0.10, 0.20, 0.50],
        "orpoos": 0.10,
        "orgday": 14,
        "orgprb": 0.90,
        # order variable cost by volume
        # $1000 truck / 3243.6 Ft^3
        "orgvar": 0.3084,
        "orgxrg": True,
      },
      "rdc": {
        "name": "regional distribution center",
        "ordays": [1, 2, 3],
        "orprob": [0.10, 0.30, 0.60],
        "orpoos": 0.01,
        "orgday": 3,
        "orgprb": 0.95,
        # order variable cost by volume
        # $500 truck / 3243.6 Ft^3
        "orgvar": 0.1542,
        "orgxrg": False,

      },
      "eco": {
        "name": "ecommerce distribution center",
        "xrdays": [1, 2, 3],
        "xrprob": [0.20, 0.50, 0.30],
        "xrpoos": 0.0125,
        "xrgday": 2,
        "xrgprb": 0.9875,
        # order variable cost by volume
        # $1500 truck / 3243.6 Ft^3
        "xrgvar": 0.4626,
      },
    }
  },
  # skus
  "skus": [
    {
      "tag": '10000000',
      "name": 'Cereal 0x00',
      # sku cost and revenue architecture
      "length": 1.1428,
      "depth": 1.2857,
      "height": 1.5714,
      "urvc": 1.99,
      "urvn": 3.98,
      "size": 12,
      # sku in store configuration
      "sfcols": 4,
      "sfrows": 5,
      # TODO: top share by shelf
      "tpcols": 1,
      "tprows": 8,
      # TODO: back share by store
      "bkcols": 1000,
      "bkrows": 1000,
      # sku order express architecture
      "orseries": "ass",
      "xrseries": "eco",
      # sku demand
      "asksmn": 20.54,
      "askssd": 10.28,
      # ledger
      "sfu": 46,
      "tpu": 22,
      "bku": 214,
    },
    {
      "tag": '10010000',
      "name": 'Cereal 0x01',
      "length": 0.7834,
      "depth": 0.1875,
      "height": 1.0500,
      "urvc": 3.32,
      "urvn": 3.98,
      "size": 8,
      "sfcols": 4,
      "sfrows": 10,
      "tpcols": 1,
      "tprows": 16,
      "bkcols": 1000,
      "bkrows": 1000,
      "orseries": "rdc",
      "xrseries": "eco",
      "asksmn": 2.75,
      "askssd": 2.54,
      "sfu": 32,
      "tpu": 14,
      "bku": 48,
    },
    {
      "tag": '10010001',
      "name": 'Cereal 0x01 High Demand',
      "length": 0.7834,
      "depth": 0.1875,
      "height": 1.0500,
      "urvc": 3.32,
      "urvn": 3.98,
      "size": 8,
      "sfcols": 1,
      "sfrows": 10,
      "tpcols": 1,
      "tprows": 4,
      "bkcols": 1000,
      "bkrows": 1000,
      "orseries": "ass",
      "xrseries": "eco",
      "asksmn": 4.50,
      "askssd": 4.28,
      "sfu": 8,
      "tpu": 4,
      "bku": 48,
    },
    {
      "tag": '10010010',
      "name": 'Cereal 0x01 High Profit',
      "length": 0.7834,
      "depth": 0.1875,
      "height": 1.0500,
      "urvc": 3.32,
      "urvn": 6.98,
      "size": 8,
      "sfcols": 1,
      "sfrows": 10,
      "tpcols": 1,
      "tprows": 4,
      "bkcols": 1000,
      "bkrows": 1000,
      "orseries": "rdc",
      "xrseries": "eco",
      "asksmn": 2.75,
      "askssd": 2.54,
      "sfu": 8,
      "tpu": 4,
      "bku": 48,
    },
  ],
}


def initiate_store_ledger(payload):

  store_fields = [
    #"tag",
    "name",
    "rvar",
    "svar",
    "cvar",
    "vvar",
    "mvst",
    "mvts",
    "mvbf",
    "mvfb",
    "info",
  ]

  store_sku_fields = {
    "orseries": [
      "ordays",
      "orprob",
      "orpoos",
      "orgday",
      "orgprb",
      "orgvar",
      "orgxrg",
    ],
    "xrseries": [
      "xrdays",
      "xrprob",
      "xrpoos",
      "xrgday",
      "xrgprb",
      "xrgvar",
    ],
  }

  sku_fields = [
    #"tag",
    "name",
    "length",
    "depth",
    "height",
    "urvc",
    "urvn",
    "size",
    "sfcols",
    "sfrows",
    "tpcols",
    "tprows",
    "bkcols",
    "bkrows",
    "asksmn",
    "askssd",
  ]

  sku_ledger_fields = [
    "sfu",
    "tpu",
    "bku"
  ]

  ledger_fields = [
    "ask",
    "sfx",
    "tpx",
    "bkx",
    "sun",
    "oun",
    "xun",
    "rex",
    "sex",
    "mex",
    "oex",
    "xex",
    "cex",
    "vex",
    "rvn",
    "rvc",
    "rvo",
  ]


  with transaction.atomic():
    try:
      # store
      store, store_created = Store.objects.get_or_create(
        tag=payload['tag']
      )
      for field in store_fields:
        store.__dict__[field] = payload[field]
      store.save()
      # skus and ledgers w.r.t store
      skus = []
      ledgers = []
      for skuload in payload['skus']:
        # sku init w.r.t store
        # assert skuload['sfu'] <= skuload['sfcols'] * skuload['sfrows'], 'Overload'
        # assert skuload['tpu'] <= skuload['tpcols'] * skuload['tprows'], 'Overload'
        # assert skuload['bku'] <= skuload['bkcols'] * skuload['bkrows'], 'Overload'
        # auto adjust skuload units on shelf, top, and backroom because optimizer requires flexibility,
        # move skus on shelf and top to back when overload because optimizer want less and less facing.
        units = 0
        if skuload['sfu'] > skuload['sfcols'] * skuload['sfrows']:
          units += skuload['sfu'] - skuload['sfcols'] * skuload['sfrows']
          skuload['sfu'] = skuload['sfcols'] * skuload['sfrows']
        if skuload['tpu'] > skuload['tpcols'] * skuload['tprows']:
          units += skuload['tpu'] - skuload['tpcols'] * skuload['tprows']
          skuload['tpu'] = skuload['tpcols'] * skuload['tprows']
        # assume infinity capacity in backroom
        skuload['bku'] += units
        # sku init w.r.t store
        sku, sku_created = Sku.objects.get_or_create(
          store=store, tag=skuload['tag']
        )
        for fk, fv in store_sku_fields.items():
          for field in fv:
            sku.__dict__[field] = payload['info']['transportation'][skuload[fk]][field]
        for field in sku_fields:
          sku.__dict__[field] = skuload[field]
        sku.save()
        # ledger init w.r.t sku
        ledger, ledger_created = Ledger.objects.get_or_create(
          sku=sku, day=0
        )
        for field in sku_ledger_fields:
          ledger.__dict__[field] = skuload[field]
        for field in ledger_fields:
          ledger.__dict__[field] = 0
        ledger.save()
        # skus and ledgers
        skus.append(sku)
        ledgers.append(ledger)
    except Exception as inst:
      logger.error('exception instance type: {}'.format(type(inst)))
      logger.error('exception instance args: {}'.format(inst.args))
      logger.error('exception instance self: {}'.format(inst))

  return store, skus, ledgers


initiator_defaults = initiate_store_ledger

