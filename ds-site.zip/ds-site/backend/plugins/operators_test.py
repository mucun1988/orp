"""Operate store w.r.t event and create ledger.
Author: yg <gyang274@gmail.com>

python manage.py shell < backend/plugins/operators_test.py
"""

from backend.plugins.initiators import payload_defaults
from backend.plugins.initiators import initiator_defaults
from backend.plugins.resolvers import resolver_defaults
from backend.plugins.triggerrs import triggerr_defaults
from backend.plugins.operators import operator_defaults
from backend.plugins.viewers import viewer_defaults

from backend.plugins.operators import Manager


# Tag ML-OPR-0x01

tag = 'ML-OPR-0x01'

payload = payload_defaults
payload['tag'] = tag
payload['name'] = 'Operator Test'

manager = Manager(
  tag=tag,
  day=1,
  payload=payload,
  initiator=initiator_defaults,
  resolver=resolver_defaults,
  triggerr=triggerr_defaults,
  random_seed=714285,
  operator=operator_defaults,
  viewer=viewer_defaults,
)

manager.run(days=10)
