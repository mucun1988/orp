"""select sku sfcols architecture w.r.t maximize store net profit.
Author: yg <gyang274@gmail.com>
"""

import itertools

from operator import itemgetter

from ortools.linear_solver import pywraplp

from .logger import logger

from .viewers import get_store_ledger_sku_view


def select_from_mixed_integer_solver(w, v, Wmin, Wmax, Nmin, Nmax):
  """Given: w_{ij}, and v_{ij}

  Solve: \max \sum_{ij} v_{ij} * b_{ij}

    s.t. \sum_{ij} w_{ij} * b_{ij} >= Wmin
         \sum_{ij} w_{ij} * b_{ij} <= Wmax
         \sum_i b_{i0} >= Nmin
         \sum_i b_{i0} <= Nmax
         \sum_j b_{ij} == 1 \any i
         b_{ij} \in (0, 1)

  TODO:
    add constraints on b_{i0} == 0 for some i, e.g., skus of Great Value must be kept.
    inputs shall be a list of k-indices.
  """

  solver = pywraplp.Solver(
    'SolveMIP', pywraplp.Solver.CBC_MIXED_INTEGER_PROGRAMMING
  )

  # b_{ij}, s.t., b_{ij} \in (0, 1)
  # b = [
  #   [
  #     solver.IntVar(
  #       0.0, 1.0, 'b-' + str(i) + '-' + str(j)
  #     ) for j, wij in enumerate(wi)
  #   ] for i, wi in enumerate(w)
  # ]
  # 2018.08.22: bug when use (0, 1)
  # solver returns non-optimium results as optimium reached
  # relaxed condition is ok as the condition on sum guarded
  b = [
    [
      solver.IntVar(
        0.0, solver.infinity(), 'b-' + str(i) + '-' + str(j)
      ) for j, wij in enumerate(wi)
    ] for i, wi in enumerate(w)
  ]

  # \sum_j b_{ij} >= xmin \any i
  # \sum_j b_{ij} <= xmax \any i
  # for i, bi in enumerate(b):
  #   exec(f'constraint_{i} = solver.Constraint(xmin, xmax)')
  #   for j, bij in enumerate(bi):
  #     exec(f'constraint_{i}.SetCoefficient(b[{i}][{j}], 1)')
  # 2018.09.04: xmin == xmax == 1
  for i, bi in enumerate(b):
    solver.Add(solver.Sum(b[i]) == 1)

  # 2018.09.04
  # set a limit on number of skus to be removed
  # \sum_i b_{i0} >= Nmin
  # \sum_i b_{i0} <= Nmax
  constraint_n = solver.Sum([bi[0] for bi in b])
  solver.Add(
    Nmin <= constraint_n <= Nmax
  )

  # \sum_{ij} w_{ij} * b_{ij} >= Wmin
  # \sum_{ij} w_{ij} * b_{ij} <= Wmax
  Wmin = Wmin or -solver.infinity()
  Wmax = Wmax or  solver.infinity()
  # constraint_w = solver.Constraint(Wmin, Wmax)
  # for i, bi in enumerate(b):
  #   for j, bij in enumerate(bi):
  #     exec(f'constraint_w.SetCoefficient(b[{i}][{j}], w[{i}][{j}])')
  constraint_w = solver.Sum(
    [bij * wij for bw in zip(b, w) for bij, wij in zip(*bw)]
  )
  solver.Add(
    Wmin <= constraint_w <= Wmax
  )

  # \max \sum_{ij} v_{ij} * b_{ij}
  # objective = solver.Objective()
  # for i, bi in enumerate(b):
  #   for j, bij in enumerate(bi):
  #     exec(f'objective.SetCoefficient(b[{i}][{j}], v[{i}][{j}])')
  # objective.SetMaximization()
  objective_v = solver.Sum(
    [bij * vij for bv in zip(b, v) for bij, vij in zip(*bv)]
  )
  solver.Maximize(objective_v)

  # solve the problem and print the solution.
  result_status = solver.Solve()
  # check the problem has an optimal solution.
  assert result_status == pywraplp.Solver.OPTIMAL

  # The solution looks legit (when using solvers other than
  # GLOP_LINEAR_PROGRAMMING, verifying the solution is highly recommended!).
  assert solver.VerifySolution(1e-7, True)

  logger.info('Number of variables: {}'.format(solver.NumVariables()))
  logger.info('Number of constraints: {}'.format(solver.NumConstraints()))

  # The objective value of the solution.
  logger.info('Optimal objective value: {}'.format(solver.Objective().Value()))

  # The value of each variable in the solution.
  # for i, bi in enumerate(b):
  #   for j, bij in enumerate(bi):
  #     logger.info('{}: {}'.format(bij.name(), bij.solution_value()))

  # solution w.r.t w, v
  s = [
    [
      bij.solution_value(
      ) for j, bij in enumerate(bi)
    ] for i, bi in enumerate(b)
  ]

  return s


def _select_get_store_length_min_max(payload):

  store_length = sum(
    sku['length'] * sku['sfcols'] for sku in payload['skus']
  )

  skus_length = [
    sku['length'] for sku in payload['skus']
  ]

  skus_sfcols = [
    sku['sfcols'] for sku in payload['skus']
  ]

  skus_length_min = min(skus_length) * 1.20

  skus_length_max = max(skus_length) * 0.80

  skus_sfcols_num = len(skus_sfcols)

  store_length_min_ratio = max(0.90, 1 - min(skus_sfcols_num * 0.01, 1) * skus_length_max / store_length)

  store_length_max_ratio = min(1 + min(skus_sfcols_num * 0.01, 1) * skus_length_min / store_length, 1.01)

  store_length_min = store_length * store_length_min_ratio

  store_length_max = store_length * store_length_max_ratio

  return store_length, store_length_min, store_length_max


def select_skus_sfcols_from_extended(tag, payload, strategy):
  """select skus sfcols combination w.r.t net profit.

  :param:
    tag: should be a tag of extended, e.g., with -X in supervisor run.
    payload: should be a payload of initiate, e.g., with tag -I in supervisor run to extract Wmin, Wmax.
    strategy:
      (Nmin, Nmax, options):
        Nmin: min number of skus chosen.
        Nmax: max number of skus chosen.
        options: Keep Great Value, etc.
  """

  # aggregate by sku over days
  store_ledger_sku_view = get_store_ledger_sku_view(tag)

  store_ledger_sku_view = sorted(store_ledger_sku_view, key=itemgetter('sku'))

  # sku sfcols and net profit in corresponding list
  skus = []
  skus_w = []
  skus_v = []
  for k, g in itertools.groupby(
    store_ledger_sku_view, key=lambda x: x['sku'].split('-')[0]
  ):
    glist = list(g)
    # glist = sorted(glist, key=lambda x: x['avgsfcols'])
    glist = sorted(glist, key=lambda x: int(x['sku'].split('-')[1]))
    gskus = []
    gskus_w = []
    gskus_v = []
    for sku in glist:
      gskus.append(sku)
      gskus_w.append(sku['avglength'])
      gskus_v.append(sku['avgrvxlength'] * max(0.01, sku['avglength']))
    skus.append(gskus)
    skus_w.append(gskus_w)
    skus_v.append(gskus_v)

  # optimize w.r.t payload init length
  # get the target store length w.r.t current store length.
  store_length, store_length_min, store_length_max = _select_get_store_length_min_max(payload)

  Nmin = strategy[0] or 0
  Nmax = strategy[1] or len(skus)
  skus_s = select_from_mixed_integer_solver(
    skus_w, skus_v, store_length_min, store_length_max, Nmin=len(skus) - Nmax, Nmax=len(skus) - Nmin
  )

  solution = {}
  for i, skus_si in enumerate(skus_s):
    for j, skus_sij in enumerate(skus_si):
      if skus_sij == 1:
        solution.update({
          skus[i][j]['sku'].split('-')[0]: int(skus[i][j]['avgsfcols'])
        })

  return solution


selector_defaults = select_skus_sfcols_from_extended

