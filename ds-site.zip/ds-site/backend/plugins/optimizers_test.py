"""Optimize store skus architecture w.r.t net profit per linear ft.
Author: yg <gyang274@gmail.com>

python manage.py shell < backend/plugins/optimizers_test.py
"""

from backend.plugins.initiators import payload_defaults
from backend.plugins.initiators import initiator_defaults
from backend.plugins.resolvers import resolver_defaults
from backend.plugins.triggerrs import triggerr_defaults
from backend.plugins.operators import operator_defaults
from backend.plugins.selectors import selector_defaults
from backend.plugins.viewers import viewer_defaults

from backend.plugins.operators import Manager
from backend.plugins.optimizers import Supervisor



# Tag ML-OPT-0x01

tag = 'ML-OPT-0x01'

payload = payload_defaults
payload['tag'] = tag
payload['name'] = 'Optimizer Test'

supervisor = Supervisor(
  tag=tag,
  day=1,
  payload=payload,
  initiator=initiator_defaults,
  resolver=resolver_defaults,
  triggerr=triggerr_defaults,
  random_seed=0,
  operator=operator_defaults,
  selector=selector_defaults,
  viewer=viewer_defaults
)

supervisor.run(days=10)
