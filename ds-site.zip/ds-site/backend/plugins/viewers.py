"""Generate aggregate leggen view over ledger.
Author: yg <gyang274@gmail.com>
"""

from functools import partial

from django.db.models import Avg, Count, Max, Min, Sum

from backend.models import Store, Sku, Event, Ledger, Cache

from .logger import logger


AGGREGATABLE_LEDGER_FIELDS = [
  # sku
  # name,
  # day
  'ask',
  'urvc',
  'urvn',
  'urvm',
  'sfcols',
  'length',
  'sfu',
  'sfv',
  'sfx',
  'sfp',
  'tpu',
  'tpv',
  'tpx',
  'tpp',
  'bku',
  'bkv',
  'bkx',
  'bkp',
  'smu',
  'smv',
  'smx',
  'smp',
  'sun',
  'oun',
  'xun',
  'rex',
  'sex',
  'mex',
  'oex',
  'xex',
  'cex',
  'vex',
  'wex',
  'zex',
  'rvn',
  'rvc',
  'rvm',
  'rvx',
  'rvo',
]


def aggregate_ledgers_day_over_skus(ledgers, sku, name):
  """aggreate ledgers by day over skus
  """

  # day
  day_range = ledgers.aggregate(Min('day'), Max('day'))

  assert day_range['day__min'] == day_range['day__max']

  day = day_range['day__min']

  # ledger
  ledger_day = dict(
    sku=sku,
    name=name,
    day=day,
    ask=0,
    urvc=0.00,
    urvn=0.00,
    urvm=0.00,
    sfcols=0,
    length=0,
    sfu=0,
    sfv=0,
    sfx=0,
    sfp=0,
    tpu=0,
    tpv=0,
    tpx=0,
    tpp=0,
    bku=0,
    bkv=0,
    bkx=0,
    bkp=0,
    smu=0,
    smv=0,
    smx=0,
    smp=0,
    sun=0,
    oun=0,
    xun=0,
    rex=0.00,
    sex=0.00,
    mex=0.00,
    oex=0.00,
    xex=0.00,
    cex=0.00,
    vex=0.00,
    wex=0.00,
    zex=0.00,
    rvn=0.00,
    rvc=0.00,
    rvm=0.00,
    rvx=0.00,
    rvo=0.00,
    # aggregate
    sfxsmx=0.00,
    tpxsmx=0.00,
    bkxsmx=0.00,
    sfpsmp=0.00,
    tppsmp=0.00,
    bkpsmp=0.00,
  )

  ledger_day_fields = AGGREGATABLE_LEDGER_FIELDS

  for ledger in ledgers:
    for field in ledger_day_fields:
      # __dict__ access to model fields only, not property
      # ledger_day[field] += ledger.__dict__[field]
      # __getattribute__ access to both model fields and property
      ledger_day[field] += ledger.__getattribute__(field)

  ledger_day['sfxsmx'] = ledger_day['sfx'] / max(1, ledger_day['smx'])
  ledger_day['tpxsmx'] = ledger_day['tpx'] / max(1, ledger_day['smx'])
  ledger_day['bkxsmx'] = ledger_day['bkx'] / max(1, ledger_day['smx'])

  ledger_day['sfpsmp'] = ledger_day['sfp'] / max(1, ledger_day['smp'])
  ledger_day['tppsmp'] = ledger_day['tpp'] / max(1, ledger_day['smp'])
  ledger_day['bkpsmp'] = ledger_day['bkp'] / max(1, ledger_day['smp'])

  return ledger_day


def aggregate_ledgers_sku_over_days(ledgers, sku, name):
  """aggreate ledgers by sku over days
  """

  day = len(ledgers)

  # ledger
  ledger_sku = dict(
    sku=sku,
    name=name,
    day=day,
    ask=0,
    urvc=0.00,
    urvn=0.00,
    urvm=0.00,
    sfcols=0,
    length=0,
    sfu=0,
    sfv=0,
    sfx=0,
    sfp=0,
    tpu=0,
    tpv=0,
    tpx=0,
    tpp=0,
    bku=0,
    bkv=0,
    bkx=0,
    bkp=0,
    smu=0,
    smv=0,
    smx=0,
    smp=0,
    sun=0,
    oun=0,
    xun=0,
    rex=0.00,
    sex=0.00,
    mex=0.00,
    oex=0.00,
    xex=0.00,
    cex=0.00,
    vex=0.00,
    wex=0.00,
    zex=0.00,
    rvn=0.00,
    rvc=0.00,
    rvm=0.00,
    rvx=0.00,
    rvo=0.00,
    # aggregate
    sfxsmx=0.00,
    tpxsmx=0.00,
    bkxsmx=0.00,
    sfpsmp=0.00,
    tppsmp=0.00,
    bkpsmp=0.00,
    # condition
    smxday=0,
    ounday=0,
    xunday=0,
    rvoday=0,
    # aggregate
    avgask=0,
    avgurvc=0.00,
    avgurvn=0.00,
    avgurvm=0.00,
    avgsfcols=0,
    avglength=0,
    avgsfu=0,
    avgsfv=0,
    avgsfx=0,
    avgtpu=0,
    avgtpv=0,
    avgtpx=0,
    avgbku=0,
    avgbkv=0,
    avgbkx=0,
    avgsmu=0,
    avgsmv=0,
    avgsmx=0,
    avgsun=0,
    avgoun=0,
    avgxun=0,
    avgrex=0.00,
    avgsex=0.00,
    avgmex=0.00,
    avgoex=0.00,
    avgxex=0.00,
    avgcex=0.00,
    avgvex=0.00,
    avgwex=0.00,
    avgzex=0.00,
    avgrvn=0.00,
    avgrvc=0.00,
    avgrvm=0.00,
    avgrvx=0.00,
    avgrvo=0.00,
    avgsfxsmx=0.00,
    avgtpxsmx=0.00,
    avgbkxsmx=0.00,
    avgsfpsmp=0.00,
    avgtppsmp=0.00,
    avgbkpsmp=0.00,
    pcgsmxday=0,
    pcgounday=0,
    pcgxunday=0,
    pcgrvoday=0,
    avgrvxsfcols=0.00,
    avgrvxlength=0.00,
  )

  ledger_sku_fields = AGGREGATABLE_LEDGER_FIELDS

  ledger_sku_counts = [
    'smx',
    'oun',
    'xun',
    'rvo',
  ]

  for ledger in ledgers:
    for field in ledger_sku_fields:
      if isinstance(ledger, dict):
        # ledger construct from aggregate_ledgers_day_over_skus
        ledger_sku[field] += ledger[field]
      else:
        ledger_sku[field] += ledger.__getattribute__(field)
    for field in ledger_sku_counts:
      if isinstance(ledger, dict):
        ledger_field_value = ledger[field]
      else:
        ledger_field_value = ledger.__getattribute__(field)

      if ledger_field_value  > 0:
        ledger_sku[field + 'day'] += 1

  ledger_sku['sfxsmx'] = ledger_sku['sfx'] / max(1, ledger_sku['smx'])
  ledger_sku['tpxsmx'] = ledger_sku['tpx'] / max(1, ledger_sku['smx'])
  ledger_sku['bkxsmx'] = ledger_sku['bkx'] / max(1, ledger_sku['smx'])

  ledger_sku['sfpsmp'] = ledger_sku['sfp'] / max(1, ledger_sku['smp'])
  ledger_sku['tppsmp'] = ledger_sku['tpp'] / max(1, ledger_sku['smp'])
  ledger_sku['bkpsmp'] = ledger_sku['bkp'] / max(1, ledger_sku['smp'])

  for field in ledger_sku_fields:
    ledger_sku['avg' + field] = ledger_sku[field] / max(1, day)
    if field in ledger_sku_counts:
      ledger_sku['pcg' + field + 'day'] = ledger_sku[field + 'day'] / max(1, day)

  ledger_sku['avgsfxsmx'] = ledger_sku['sfxsmx']
  ledger_sku['avgtpxsmx'] = ledger_sku['tpxsmx']
  ledger_sku['avgbkxsmx'] = ledger_sku['bkxsmx']

  ledger_sku['avgsfpsmp'] = ledger_sku['sfpsmp']
  ledger_sku['avgtppsmp'] = ledger_sku['tppsmp']
  ledger_sku['avgbkpsmp'] = ledger_sku['bkpsmp']

  # calculate the average profit over each facing
  ledger_sku['avgrvxsfcols'] = \
    ledger_sku['avgrvx'] / max(1, ledger_sku['avgsfcols'])

  # calculate the average profit over linear foot
  ledger_sku['avgrvxlength'] = \
    ledger_sku['avgrvx'] / max(0.01, ledger_sku['avglength'])

  return ledger_sku


def get_store_ledger_day_view_from_aggregation(store):
  """aggregate store ledgers by day over skus
  """

  ledgers = Ledger.objects.filter(
    sku__store__tag=store, day__gte=1
  ).order_by(
    'day', 'sku'
  )

  sku_num = ledgers.aggregate(Count('sku', distinct=True))['sku__count']

  sku_str = 'AGGX' + str(sku_num)

  sku_name = 'Store SKUs Aggregated - ' + str(sku_num)

  days = [
    x[0] for x in ledgers.order_by('day').values_list('day', ).distinct()
  ]

  store_ledger_day_view = [
    aggregate_ledgers_day_over_skus(
      ledgers=ledgers.filter(day=day),
      sku=sku_str,
      name=sku_name,
    ) for day in days
  ]

  return store_ledger_day_view


def set_store_ledger_day_view_into_cache(store):

  store_ledger_day_view = get_store_ledger_day_view_from_aggregation(store)

  for store_ledger_day_view_sketch in store_ledger_day_view:
    cache, cache_created = Cache.objects.get_or_create(
      tag='store_ledger_day_view',
      store=store,
      sku=store_ledger_day_view_sketch['sku'],
      day=store_ledger_day_view_sketch['day'],
      content=store_ledger_day_view_sketch,
    )


def get_store_ledger_day_view_from_cache(store):

  # order by jsonfield field is not supported yet,
  # use rawsql when really needed
  # ledger_day_view_cache = Cache.objects.filter(
  #   tag='ledger_day_view', store=tag,
  # ).order_by('content__day')

  store_ledger_day_view_cache = Cache.objects.filter(
    tag='store_ledger_day_view', store=store,
  ).order_by('day')

  store_ledger_day_view = [
    cache.content for cache in store_ledger_day_view_cache
  ]

  return store_ledger_day_view


def get_store_ledger_sku_view_from_aggregation(store):
  """aggregate store ledgers by sku over days.
  """

  ledgers = Ledger.objects.filter(
    sku__store__tag=store, day__gte=1
  ).order_by(
    'sku', 'day'
  )

  skus = Sku.objects.filter(
    store__tag=store
  )

  store_ledger_sku_view = [
    aggregate_ledgers_sku_over_days(
      ledgers=ledgers.filter(sku=sku),
      sku=sku.tag,
      name=sku.name,
    ) for sku in skus
  ]

  return store_ledger_sku_view


def set_store_ledger_sku_view_into_cache(store):

  store_ledger_sku_view = get_store_ledger_sku_view_from_aggregation(store)

  for store_ledger_sku_view_sketch in store_ledger_sku_view:
    cache, cache_created = Cache.objects.get_or_create(
      tag='store_ledger_sku_view',
      store=store,
      sku=store_ledger_sku_view_sketch['sku'],
      day=store_ledger_sku_view_sketch['day'],
      content=store_ledger_sku_view_sketch,
    )


def get_store_ledger_sku_view_from_cache(store):

  store_ledger_sku_view_cache = Cache.objects.filter(
    tag='store_ledger_sku_view', store=store,
  ).order_by('sku')

  store_ledger_sku_view = [
    cache.content for cache in store_ledger_sku_view_cache
  ]

  return store_ledger_sku_view


def get_store_ledger_overview_from_aggregation(store):

  ledgers = Ledger.objects.filter(
    sku__store__tag=store, day__gte=1
  ).order_by(
    'day', 'sku'
  )

  sku_num = ledgers.aggregate(Count('sku', distinct=True))['sku__count']

  sku_str = 'AGGX' + str(sku_num)

  sku_name = 'Store SKUs Aggregated - ' + str(sku_num)

  days = [
    x[0] for x in ledgers.order_by('day').values_list('day', ).distinct()
  ]

  ledger_day_view = [
    aggregate_ledgers_day_over_skus(
      ledgers=ledgers.filter(day=day),
      sku=sku_str,
      name=sku_name,
    ) for day in days
  ]

  ledger_overview = [
    aggregate_ledgers_sku_over_days(
      ledgers=ledger_day_view,
      sku=sku_str,
      name=sku_name,
    )
  ]

  return ledger_overview


def set_store_ledger_overview_into_cache(store):

  store_ledger_overview = get_store_ledger_overview_from_aggregation(store)

  for store_ledger_overview_sketch in store_ledger_overview:
    cache, cache_created = Cache.objects.get_or_create(
      tag='store_ledger_overview',
      store=store,
      sku=store_ledger_overview_sketch['sku'],
      day=store_ledger_overview_sketch['day'],
      content=store_ledger_overview_sketch,
    )

  return store_ledger_overview


def get_store_ledger_overview_from_cache(store):

  store_ledger_overview_cache = Cache.objects.filter(
    tag='store_ledger_overview', store=store,
  )

  store_ledger_overview = [
    cache.content for cache in store_ledger_overview_cache
  ]

  return store_ledger_overview


def get_from_cache_with_set_into_cache_fallback(tag, get_from_cache, set_into_cache):

  view = get_from_cache(tag)

  if len(view) == 0:
    logger.info(f'{get_from_cache}({tag}) return 0 results, fallback to {set_into_cache}({tag}).')
    view = set_into_cache(tag)

  return view


get_store_ledger_day_view = partial(
  get_from_cache_with_set_into_cache_fallback,
  get_from_cache=get_store_ledger_day_view_from_cache,
  set_into_cache=set_store_ledger_day_view_into_cache,
)


get_store_ledger_sku_view = partial(
  get_from_cache_with_set_into_cache_fallback,
  get_from_cache=get_store_ledger_sku_view_from_cache,
  set_into_cache=set_store_ledger_sku_view_into_cache,
)


get_store_ledger_overview = partial(
  get_from_cache_with_set_into_cache_fallback,
  get_from_cache=get_store_ledger_overview_from_cache,
  set_into_cache=set_store_ledger_overview_into_cache,
)


def set_store_ledger_views(store):

  set_store_ledger_overview_into_cache(store)

  set_store_ledger_sku_view_into_cache(store)

  set_store_ledger_day_view_into_cache(store)


viewer_defaults = set_store_ledger_views
