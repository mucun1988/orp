"""Optimize store skus architecture w.r.t net profit per linear ft.
Author: yg <gyang274@gmail.com>
"""

import numpy as np

from scipy import optimize, stats

from django.db import transaction

from django.core.exceptions import ObjectDoesNotExist

from backend.models import Store, Sku, Event, Ledger, Cache

from .logger import logger

from .utilities import set_instance


def get_asks_over_sfcols_ratio(x):

  if x < 1:
    r = 1.00
  else:
    r = 1.00 + np.log(1.00 + np.log10(x) * np.sqrt(x))

  return r


def optimize_initiate_payload_sfcols(payload, cmin=0, alpha=0.16, tpv_sfv_ratio=0.40, bkv_sfv_ratio=2.50):
  """initiate payload w.r.t sfcols.
    initiate sku with sfcols from cmin to
      max(sfcols + 1.0, (1 - alpha)% demand over max(lead time) / sfrows).
  :param cmin: 0 if sku can be deleted, 1 otherwise.
  """

  payload_extended = payload.copy()

  skus = []

  for sku in payload['skus']:
    sfcmin = cmin
    # sfcmax = int(
    #   max(
    #     sku['sfcols'] + 1.0,
    #     stats.norm.isf(
    #       alpha,
    #       loc=sku['asksmn'] * max(sku['ordays']),
    #       scale=sku['askssd'] * np.sqrt(max(sku['ordays']))
    #     ) / sku['sfrows']
    #   )
    # )
    sfcmax = int(
      max(
        sku['sfcols'] * 2.0,
        stats.norm.isf(
          alpha,
          loc=sku['asksmn'] * 7,
          scale=sku['askssd'] * 2,
        ) / sku['sfrows']
      )
    )
    for sfcidx in range(sfcmin, sfcmax + 1):
      skuidx = sku.copy()
      skuidx['tag'] = sku['tag'] + '-' + str(sfcidx)
      skuidx['sfcols'] = sfcidx
      skuidx['tpcols'] = 1
      skuidx['tprows'] = np.ceil(sfcidx * sku['sfrows'] * tpv_sfv_ratio)
      skuidx['bkcols'] = 1000
      skuidx['bkrows'] = min(max(1000, np.ceil(sfcidx * sku['sfrows'] * bkv_sfv_ratio)), 2000)
      skuidx['asksmn'] = (
        sku['asksmn'] / get_asks_over_sfcols_ratio(sku['sfcols']) * get_asks_over_sfcols_ratio(sfcidx)
      )
      skuidx['askssd'] = (
        sku['askssd'] / np.sqrt(
          get_asks_over_sfcols_ratio(sku['sfcols'])
        ) * np.sqrt(
          get_asks_over_sfcols_ratio(sfcidx)
        )
      )
      if sfcidx == 0:
        skuidx['sfu'] = 0
        skuidx['tpu'] = 0
        skuidx['bku'] = 0
      skus.append(skuidx)

  payload_extended['skus'] = skus

  return payload_extended


def optimize_optimize_payload_sfcols(payload, solution):

  payload_optimize = payload.copy()

  for sku in payload_optimize['skus']:
    sku['sfcols'] = solution[sku['tag']]

  return payload_optimize


def optimize_get_store_from_solution(tagX, solution, tagO, nameO):
  """get optimize store, skus, ledgers, events from solution directly.
  """

  with transaction.atomic():
    try:
      # get store X
      store = Store.objects.get(tag=tagX)

      # get skus from store X __w.r.t optimize sfcols__
      skus = []
      for sku_tag, sku_sfcols in solution.items():
        skus.append(
          Sku.objects.get(
            store=store, tag=sku_tag + '-' + str(sku_sfcols),
          )
        )

      # set store X into store O (tag_suffix)
      set_instance(store, {
        'tag': tagO,
        'name': nameO,
      }, reset=True)

      # get events and ledgers for each sku from store X
      for sku in skus:
        events = Event.objects.filter(
          sku=sku
        )
        ledgers = Ledger.objects.filter(
          sku=sku
        )
        # set skus from store X into skus from store O
        set_instance(sku, {
          'store': store,
          'tag': sku.tag.split('-')[0],
        }, reset=True)
        # set events and ledgers for each sku from store X into store O
        for event in events:
          set_instance(event, {
            'sku': sku,
          }, reset=True)
        for ledger in ledgers:
          set_instance(ledger, {
            'sku': sku,
          }, reset=True)
    except Exception as inst:
      logger.error('Exception instance type: {}'.format(type(inst)))
      logger.error('Exception instance args: {}'.format(inst.args))
      logger.error('Exception instance self: {}'.format(inst))


class Supervisor(object):

  def __init__(self, tag, day, payload, initiator, resolver, triggerr, random_seed, operator, selector, viewer):
    self.tag = tag
    self.day = day
    self.payload = payload
    self.initiator = initiator
    self.resolver = resolver
    self.triggerr = triggerr
    self.random_seed = random_seed
    self.operator = operator
    self.selector = selector
    self.viewer = viewer

    # init tag, payload init
    self.tag_init = self.tag + '-I'
    self.payload_init = self.payload.copy()
    self.payload_init['tag'] = self.tag_init
    self.payload_init['name'] = self.payload['name'] + ' - Initiate'

    # init tag, payload xtnd
    self.tag_xtnd = self.tag + '-X'
    self.payload_xtnd = optimize_initiate_payload_sfcols(self.payload)
    self.payload_xtnd['tag'] = self.tag_xtnd
    self.payload_xtnd['name'] = self.payload['name'] + ' - Extended'

    # init tag, name optm
    self.num_skus = len(payload['skus'])
    self.optms = [
      (
        '-O-AI',
        ' - Optimized w. All Included',
        (self.num_skus, self.num_skus)
      ),
      (
        '-O-AE',
        ' - Optimized w. Any Excluded',
        (0, self.num_skus)
      ),
      (
        '-O-MX20',
        ' - Optimized w. Postive Net Profit',
        (self.num_skus - 20, self.num_skus)
      ),
    ]

    self.optms = [
      (
        self.tag + optm[0],
        self.payload['name'] + optm[1],
        optm[2]
      ) for optm in self.optms
    ]

  # init w.r.t payload
  def initiate(self, payload):
    self.initiator(payload)

  # operates w.r.t tag, days
  def operates(self, tag, days):
    self.operator(tag, self.day, days, self.resolver, self.triggerr, self.random_seed)

  def optimize(self, tag, name, strategy):
    # get the optmize store architecture w.r.t sku sfcols into solution.
    solution = self.selector(
      self.tag_xtnd, self.payload, strategy
    )
    # get the optimize store derived directly from solution.
    optimize_get_store_from_solution(
      self.tag_xtnd, solution, tag, name
    )

  def set_view(self, tag):
    self.viewer(tag)

  def set_days(self, days):
    self.day = self.day + days

  def run(self, days):
    # run init
    self.initiate(self.payload_init)
    self.operates(tag=self.tag_init, days=days)
    self.set_view(tag=self.tag_init)
    # run xtnd
    self.initiate(self.payload_xtnd)
    self.operates(tag=self.tag_xtnd, days=days)
    self.set_view(tag=self.tag_xtnd)
    # run optm
    for tag_optm, name_optm, strategy in self.optms:
      self.optimize(
        tag=tag_optm, name=name_optm, strategy=strategy
      )
      self.set_view(tag=tag_optm)
    # set days
    self.set_days(days=days)

