"""Resolve events over ledger.
Author: yg <gyang274@gmail.com>

python manage.py shell < backend/plugins/selectors_test.py
"""

from backend.plugins.initiators import payload_defaults
from backend.plugins.initiators import initiator_defaults
from backend.plugins.resolvers import resolver_defaults
from backend.plugins.triggerrs import triggerr_defaults
from backend.plugins.selectors import selector_defaults
from backend.plugins.viewers import viewer_defaults

from backend.plugins.operators import Manager
from backend.plugins.optimizers import Supervisor

from backend.plugins.utilities import set_instance, view_instance, set_ledger_next_day


import itertools

from operator import itemgetter
from ortools.linear_solver import pywraplp

from backend.plugins.viewers import get_store_ledger_sku_view
from backend.plugins.selectors import _select_gskus_wave_from_glist


tag = 'ML-OPT-0x01'

payload = payload_defaults
payload['tag'] = tag
payload['name'] = 'Optimizer Test'

store_ledger_sku_view = get_store_ledger_sku_view(payload['tag'] + '-X')

store_ledger_sku_view = sorted(store_ledger_sku_view, key=itemgetter('sku'))

# sku sfcols and net profit in corresponding list
skus = []
skus_w = []
skus_v = []
for k, g in itertools.groupby(
  store_ledger_sku_view, key=lambda x: x['sku'].split('-')[0]
):
  glist = list(g)
  gskus, gskus_w, gskus_v = _select_gskus_wave_from_glist(glist, strategy=-1)
  skus.append(gskus)
  skus_w.append(gskus_w)
  skus_v.append(gskus_v)

