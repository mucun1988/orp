from django_filters import rest_framework as filters

from .models import Store, Sku, Event, Ledger, Cache
from .serializers import StoreSerializer, SkuSerializer, EventSerializer, LedgerSerializer, CacheSerializer


class EventFilter(filters.FilterSet):

  store = filters.CharFilter(field_name='sku__store__tag')

  sku = filters.CharFilter(field_name='sku__tag')

  class Meta:
    model = Event
    fields = ['store', 'sku', 'day', ]


class LedgerFilter(filters.FilterSet):

  store = filters.CharFilter(field_name='sku__store__tag')

  sku = filters.CharFilter(field_name='sku__tag')

  class Meta:
    model = Ledger
    fields = ['store', 'sku', 'day', ]

