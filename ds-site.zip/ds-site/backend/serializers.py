# from collections import defaultdict

# from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.db.models import Avg, Count, Max, Min, Sum

from rest_framework import serializers

from .models import Store, Sku, Event, Ledger, Cache


class PropertyModelSerializer(serializers.ModelSerializer):

  def get_field_names(self, declared_fields, info):
    expanded_fields = super(PropertyModelSerializer, self).get_field_names(declared_fields, info)
    if getattr(self.Meta, 'extra_fields', None):
      expanded_fields = expanded_fields + self.Meta.extra_fields
    return expanded_fields


class StoreSerializer(serializers.ModelSerializer):

  class Meta:
    model = Store
    fields = '__all__'


class SkuSerializer(PropertyModelSerializer):

  store = serializers.SlugRelatedField(slug_field='tag', read_only=True)

  class Meta:
    model = Sku
    fields = '__all__'
    extra_fields = ['volume', 'urvm', ]


class EventSerializer(serializers.ModelSerializer):

  store = serializers.SerializerMethodField()

  def get_store(self, instance):
    return instance.sku.store.tag

  sku = serializers.SlugRelatedField(slug_field='tag', read_only=True)

  action = serializers.CharField(source='get_action_display')

  source = serializers.CharField(source='get_source_display')

  target = serializers.CharField(source='get_target_display')

  status = serializers.CharField(source='get_status_display')

  class Meta:
    model = Event
    fields = '__all__'


class LedgerSerializer(PropertyModelSerializer):

  store = serializers.SerializerMethodField()

  def get_store(self, instance):
    return instance.sku.store.tag

  sku = serializers.SlugRelatedField(slug_field='tag', read_only=True)

  class Meta:
    model = Ledger
    fields = '__all__'
    extra_fields = [
      'tag',
      'name',
      'urvc',
      'urvn',
      'urvm',
      'sfcols',
      'length',
      'sfv',
      'sfw',
      'sfp',
      'tpv',
      'tpw',
      'tpp',
      'bkv',
      'bkw',
      'bkp',
      'smu',
      'smv',
      'smw',
      'smx',
      'smp',
      'sfxsmx',
      'sfpsmp',
      'run',
      'ounxun',
      'wex',
      'zex',
      'rvm',
      'rvx',
    ]


class CacheSerializer(serializers.ModelSerializer):

  class Meta:
    model = Cache
    fields = '__all__'

