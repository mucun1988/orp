"""run optimization w.r.t store.
Author: yg <gyang274@gmail.com>

python manage.py shell < backend/releases/runners_plus.py
"""

# select 20 SKUs w.r.t. min-max net profit linear ft.
# min-max: lowest of maximum net profit linear ft. in all sfcols > 1

from backend.plugins.initiators import payload_defaults
from backend.plugins.initiators import initiator_defaults
from backend.plugins.resolvers import resolver_defaults
from backend.plugins.triggerrs import triggerr_defaults
from backend.plugins.operators import operator_defaults
from backend.plugins.selectors import selector_defaults
from backend.plugins.viewers import viewer_defaults

from backend.plugins.operators import Manager
from backend.plugins.optimizers import Supervisor

from backend.releases.loaders import loader_wStoreTE_H
from backend.releases.loaders import loader_wStoreTE_I


DAYS = 365

# filepath = './backend/releases/teterboro-cereals-22.csv'
filepath = './backend/releases/teterboro-cereals.csv'

payload = loader_wStoreTE_I(filepath=filepath)
payload['tag'] += '-OPT'
payload['name'] += ' All SKUs'


solution = selector_defaults(
  tag=payload['tag'] + '-X',
  payload=payload,
  strategy=(188, 208)
)


from backend.plugins.optimizers import optimize_get_store_from_solution

optimize_get_store_from_solution(
  tagX=payload['tag'] + '-X',
  solution=solution,
  tagO=payload['tag'] + '-O-MX20',
  nameO=payload['name'] + ' - Optimized w. Constraints on Removing At Most 20'
)


from backend.plugins.viewers import set_store_ledger_views

set_store_ledger_views(payload['tag'] + '-O-MM20')

