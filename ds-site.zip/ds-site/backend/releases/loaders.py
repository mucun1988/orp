"""load data from csv
Author: yg <gyang274@gmail.com>
"""

import numpy as np

from functools import partial

WMT_STORE_TE_H = {
  "tag": "TE",
  "name": "Teterboro",
  # store expense structure
  # receive variable cost by pack
  # $14/hr / 48 packs per hour
  "rvar": 0.2917,
  # scan variable cost by pack
  # $14/hr / 96 packs per hour
  "svar": 0.1458,
  # holding capital cost by dollar
  # $1 * 0.10 / 365
  "cvar": 0.0002740,
  # holding space cost by Ft^3
  # $231452/month rent / 30 days / 148000 Ft^2 / 16 Ft height
  "vvar": 0.0032581,
  # move variable cost between shelf and top by unit
  # $14 / 32|20 units per hour
  "mvst": 0.4375,
  "mvts": 0.7000,
  # move variable cost between front and backroom by pack
  # $14 / 9|5 packs per hour
  "mvbf": 1.5556,
  "mvfb": 2.8000,
  # store wise order and express architecture
  "info": {
    "transportation": {
      "ass": {
        "name": "assembly distribution center",
        "ordays": [10, 11, 12, 13, 14],
        "orprob": [0.10, 0.10, 0.10, 0.20, 0.50],
        "orpoos": 0.0125,
        "orgday": 14,
        "orgprb": 0.9875,
        # order variable cost by volume
        # $1000 truck / 3243.6 Ft^3
        "orgvar": 0.3084,
        "orgxrg": False,
      },
      "rdc": {
        "name": "regional distribution center",
        "ordays": [1, 2, 3],
        "orprob": [0.10, 0.30, 0.60],
        "orpoos": 0.0125,
        "orgday": 3,
        "orgprb": 0.9875,
        # order variable cost by volume
        # $500 truck / 3243.6 Ft^3
        "orgvar": 0.1542,
        "orgxrg": False,

      },
      "eco": {
        "name": "ecommerce distribution center",
        "xrdays": [1, 2, 3],
        "xrprob": [0.20, 0.50, 0.30],
        "xrpoos": 0.0125,
        "xrgday": 2,
        "xrgprb": 0.9875,
        # order variable cost by volume
        # $1500 truck / 3243.6 Ft^3
        "xrgvar": 0.4626,
      },
    }
  },
}

WMT_STORE_TE_I = {
  "tag": "TE",
  "name": "Teterboro",
  # store expense structure
  # receive variable cost by pack
  # $14/hr / 48 packs per hour
  "rvar": 0.2917,
  # scan variable cost by pack
  # $14/hr / 96 packs per hour
  "svar": 0.1458,
  # holding capital cost by dollar
  # $1 * 0.10 / 365
  "cvar": 0.0002740,
  # holding space cost by Ft^3
  # $231452/month rent / 30 days / 148000 Ft^2 / 16 Ft height
  "vvar": 0.0032581,
  # move variable cost between shelf and top by unit
  # $14 / 32|20 units per hour
  "mvst": 0.4375,
  "mvts": 0.7000,
  # move variable cost between front and backroom by pack
  # $14 / 9|5 packs per hour
  "mvbf": 1.5556,
  "mvfb": 2.8000,
  # store wise order and express architecture
  "info": {
    "transportation": {
      "ass": {
        "name": "assembly distribution center",
        "ordays": [10, 11, 12, 13, 14],
        "orprob": [0.10, 0.10, 0.10, 0.20, 0.50],
        "orpoos": 0.10,
        "orgday": 14,
        "orgprb": 0.90,
        # order variable cost by volume
        # $1000 truck / 3243.6 Ft^3
        "orgvar": 0.3084,
        "orgxrg": True,
      },
      "rdc": {
        "name": "regional distribution center",
        "ordays": [1, 2, 3],
        "orprob": [0.10, 0.30, 0.60],
        "orpoos": 0.0125,
        "orgday": 3,
        "orgprb": 0.9875,
        # order variable cost by volume
        # $500 truck / 3243.6 Ft^3
        "orgvar": 0.1542,
        "orgxrg": False,

      },
      "eco": {
        "name": "ecommerce distribution center",
        "xrdays": [1, 2, 3],
        "xrprob": [0.20, 0.50, 0.30],
        "xrpoos": 0.0125,
        "xrgday": 2,
        "xrgprb": 0.9875,
        # order variable cost by volume
        # $1500 truck / 3243.6 Ft^3
        "xrgvar": 0.4626,
      },
    }
  },
}


def load_skus_from_csv_file(filepath, store, header=True):

  store_fields = [
    "tag",
    "name",
    "rvar",
    "svar",
    "cvar",
    "vvar",
    "mvst",
    "mvts",
    "mvbf",
    "mvfb",
    "info",
  ]

  payload = {}
  for field in store_fields:
    payload[field] = store[field]

  payload['skus'] = []
  with open(filepath, 'r') as fp:
    if header:
      fp.__next__()
    for line in fp:
      sku = {}
      skuload = line.strip().split(',')
      # remove 0 wk sale as 0 indicates out of stock
      sku_askswk = [
        int(skuload[idx]) for idx in range(11, 16) if int(skuload[idx]) > 0
      ]
      # sku has at least 1 facing and not out of stock all the time
      if int(skuload[7]) > 0 and sum(sku_askswk) > 0:
        sku['tag'] = skuload[2]
        sku['name'] = skuload[0]
        sku['length'] = float(skuload[10]) / 12
        sku['depth'] = float(skuload[8]) / 12
        sku['height'] = float(skuload[9]) / 12
        sku['size'] = int(skuload[3])
        sku['urvc'] = float(skuload[5])
        sku['urvn'] = float(skuload[4])
        sku['sfcols'] = int(skuload[7])
        sku['sfrows'] = int(np.ceil(int(skuload[6]) / int(skuload[7])))
        sku['tpcols'] = 1
        sku['tprows'] = int(np.ceil(sku['sfcols'] * sku['sfrows'] * 0.40))
        sku['bkcols'] = 1000
        sku['bkrows'] = 1000
        # transportation
        if skuload[16] == 'DC':
          sku['orseries'] = 'rdc'
        else:
          sku['orseries'] = 'ass'
        sku['xrseries'] = 'eco'
        # sku demand estimated from historical demand
        sku['asksmn'] = np.mean(sku_askswk) / 7.0
        # +1 and /2 compensate variance, e.g., sku_askswk = [2, 2, 2, 2, 2]
        # np.std([1, 1, 0, 0, 0] * 5) = 0.3780
        # np.std([1, 1, 0, 0, 0] * 3 + [2, 0, 0, 0, 0] * 2) = 0.6325
        # sku['askssd'] = (np.std(sku_askswk) + 1.0) / np.sqrt(np.ceil(7.0 / 2.0))
        # +1 in case np.std obtain 0
        if len(sku_askswk) > 1:
          sku['askssd'] = (np.std(sku_askswk) + 1.0) / np.sqrt(7.0)
        else:
          sku['askssd'] = sku['asksmn'] * 0.5
        # sku ledger init w.r.t architecture
        sku['sfu'] = int(sku['sfcols'] * sku['sfrows'])
        sku['tpu'] = int(sku['tpcols'] * sku['tprows'])
        sku['bku'] = int(np.ceil(sku['sfcols'] * sku['sfrows'] * 0.60))
        # payload
        payload['skus'].append(sku)

  return payload


loader_wStoreTE_H = partial(
  load_skus_from_csv_file, store=WMT_STORE_TE_H
)

loader_wStoreTE_I = partial(
  load_skus_from_csv_file, store=WMT_STORE_TE_I
)

if __name__ == '__main__':

  filepath = './teterboro-cereals-22.csv'

  payload = load_skus_from_csv_file(filepath, WMT_STORE_TE_I)

  print('Number of SKUs: {}'.format(len(payload['skus'])))

  print('Payload: {}'.format(payload))

