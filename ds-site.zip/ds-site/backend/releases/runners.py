"""run optimization w.r.t store.
Author: yg <gyang274@gmail.com>

python manage.py shell < backend/releases/runners.py
"""

from backend.plugins.initiators import payload_defaults
from backend.plugins.initiators import initiator_defaults
from backend.plugins.resolvers import resolver_defaults
from backend.plugins.triggerrs import triggerr_defaults
from backend.plugins.operators import operator_defaults
from backend.plugins.selectors import selector_defaults
from backend.plugins.viewers import viewer_defaults

from backend.plugins.operators import Manager
from backend.plugins.optimizers import Supervisor

from backend.releases.loaders import loader_wStoreTE_H
from backend.releases.loaders import loader_wStoreTE_I


DAYS = 365

# filepath = './backend/releases/teterboro-cereals-22.csv'
filepath = './backend/releases/teterboro-cereals.csv'

# operate w.r.t replication current store architecture
payload = loader_wStoreTE_H(filepath=filepath)
payload['tag'] += '-OPT-H'
payload['name'] += ' All SKUs, without e-commerce.'

manager = Manager(
  tag=payload['tag'],
  day=1,
  payload=payload,
  initiator=initiator_defaults,
  resolver=resolver_defaults,
  triggerr=triggerr_defaults,
  random_seed=0,
  operator=operator_defaults,
  viewer=viewer_defaults,
)
manager.run(days=DAYS)

# operate w.r.t optimization of a store architecture
payload = loader_wStoreTE_I(filepath=filepath)
payload['tag'] += '-OPT'
payload['name'] += ' All SKUs'

supervisor = Supervisor(
  tag=payload['tag'],
  day=1,
  payload=payload,
  initiator=initiator_defaults,
  resolver=resolver_defaults,
  triggerr=triggerr_defaults,
  random_seed=0,
  operator=operator_defaults,
  selector=selector_defaults,
  viewer=viewer_defaults,
)
supervisor.run(days=DAYS)


