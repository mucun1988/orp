# from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
# from django.shortcuts import render, get_object_or_404

from django.db.models import Avg, Count, Max, Min, Sum
from django.utils.timezone import datetime, timedelta

from rest_framework import views, viewsets, generics
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from django_filters import rest_framework as filters

from .models import Store, Sku, Event, Ledger, Cache
from .serializers import StoreSerializer, SkuSerializer, EventSerializer, LedgerSerializer, CacheSerializer
from .filters import EventFilter, LedgerFilter

# from .plugins.logger import logger
# from .plugins.initiators import initiator_defaults
# from .plugins.resolvers import resolver_defaults
# from .plugins.triggerrs import triggerr_defaults, triggerr_wexpress
# from .plugins.operators import Operator
# from .plugins.utilities import Status, get_payload_from_config
from .plugins.viewers import get_store_ledger_day_view
from .plugins.viewers import get_store_ledger_sku_view
from .plugins.viewers import get_store_ledger_overview
from .plugins.viewers import aggregate_ledgers_day_over_skus
from .plugins.viewers import aggregate_ledgers_sku_over_days


class StoreViewSet(viewsets.ModelViewSet):
  queryset = Store.objects.all().order_by('tag')
  serializer_class = StoreSerializer
  permission_classes = [AllowAny, ]
  lookup_field = 'tag'


class SkuViewSet(viewsets.ModelViewSet):
  queryset = Sku.objects.all().order_by('tag')
  serializer_class = SkuSerializer
  permission_classes = [AllowAny, ]
  lookup_field = 'tag'

  filter_backends = (filters.DjangoFilterBackend, )
  # filter fileds store works as look up by tag, because tag is primary_key.
  filter_fields = ('store', )


class EventViewSet(viewsets.ModelViewSet):
  queryset = Event.objects.all()
  serializer_class = EventSerializer
  permission_classes = [AllowAny, ]
  lookup_field = 'id'

  filter_backends = (filters.DjangoFilterBackend, )
  filterset_class = EventFilter


class LedgerViewSet(viewsets.ModelViewSet):
  queryset = Ledger.objects.all()
  serializer_class = LedgerSerializer
  permission_classes = [AllowAny, ]
  lookup_field = 'id'

  filter_backends = (filters.DjangoFilterBackend, )
  filterset_class = LedgerFilter


class StoreLedgerDayViewAPIView(views.APIView):
  """StoreLedgerDayViewAPIView aggregate by day over skus.
  """

  permission_classes = [AllowAny, ]

  def get(self, request, format=None):

    store = request.query_params.get('store', '')

    store_ledger_day_view = get_store_ledger_day_view(store)

    return Response(store_ledger_day_view)


class StoreLedgerSkuViewAPIView(views.APIView):
  """StoreLedgerSkuViewAPIView aggregate by sku over days.
  """

  permission_classes = [AllowAny, ]

  def get(self, request, format=None):

    store = request.query_params.get('store', '')

    store_ledger_sku_view = get_store_ledger_sku_view(store)

    return Response(store_ledger_sku_view)


class StoreLedgerOverviewAPIView(views.APIView):
  """StoreLedgerOverviewAPIView aggregate by day then by sku 'AGGX'
  """

  permission_classes = [AllowAny, ]

  def get(self, request, format=None):

    store = request.query_params.get('store', '')

    store_ledger_overview = get_store_ledger_overview(store)

    return Response(store_ledger_overview)


class SkuLedgerDayViewAPIView(views.APIView):

  permission_classes = [AllowAny, ]

  def get(self, request, format=None):

    store = request.query_params.get('store', '')

    sku = request.query_params.get('sku', '')

    sku_ledger_day_view = Ledger.objects.filter(
      sku__store__tag=store, sku__tag=sku, day__gte=1
    ).order_by('day')

    sku_ledger_day_view_serializer = LedgerSerializer(
      sku_ledger_day_view, many=True
    )

    return Response(sku_ledger_day_view_serializer.data)


class SkuLedgerOverviewAPIView(views.APIView):

  permission_classes = [AllowAny, ]

  def get(self, request, format=None):

    store = request.query_params.get('store', '')

    sku = request.query_params.get('sku', '')

    sku_ledger_overview_cache = Cache.objects.filter(
      tag='store_ledger_sku_view', store=store, sku=sku
    )

    sku_ledger_overview = [
      cache.content for cache in sku_ledger_overview_cache
    ]

    return Response(sku_ledger_overview)


class TagStoreAPIView(views.APIView):

  permission_classes = [AllowAny, ]

  def get(self, request, format=None):

    tags = [
      x[0] for x in Store.objects.values_list('tag', )
    ]
    return Response(tags)


class TagStoreSkuAPIView(views.APIView):

  permission_classes = [AllowAny, ]

  def get(self, request, format=None):

    store = request.query_params.get('store', '')

    tags = [
      x[0] for x in Sku.objects.filter(store__tag=store).values_list('tag', )
    ]

    return Response(tags)


class CacheViewSet(viewsets.ModelViewSet):
  queryset = Cache.objects.all()
  serializer_class = CacheSerializer
  permission_classes = [AllowAny, ]
  lookup_field = 'id'

  filter_backends = (filters.DjangoFilterBackend, )
  filterset_fields = ('tag', 'store', 'sku', 'day', )
