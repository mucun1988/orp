from django.db import models
from django.contrib.postgres.fields import ArrayField, JSONField
from django.utils.translation import ugettext_lazy as _
from django.utils import timezone


class Store(models.Model):

  tag = models.CharField(
    _('tag'), max_length=32, primary_key=True
  )

  name = models.CharField(
    _('name'), max_length=128, null=True, blank=True
  )

  rvar = models.FloatField(
    _('receive variable cost by pack'), null=True, blank=True
  )

  svar = models.FloatField(
    _('scan variable cost by pack'), null=True, blank=True
  )

  cvar = models.FloatField(
    _('holding variable cost w.r.t per dollar'), null=True, blank=True
  )

  vvar = models.FloatField(
    _('holding variable cost w.r.t per volume'), null=True, blank=True
  )

  mvst = models.FloatField(
    _('move labor cost w.r.t from shelf to top, varialbe cost by unit'), null=True, blank=True
  )

  mvts = models.FloatField(
    _('move labor cost w.r.t from top to shelf, varialbe cost by unit'), null=True, blank=True
  )

  mvbf = models.FloatField(
    _('move labor cost w.r.t from back to front, variable cost by pack'), null=True, blank=True
  )

  mvfb = models.FloatField(
    _('move labor cost w.r.t from front to back, variable cost by pack'), null=True, blank=True
  )

  info = JSONField(
    _('info: 1) transportation options, lead time, cost and etc., mapping to sku level.'), null=True, blank=True
  )

  def __str__(self):
    return '|'.join([
      str(self.tag),
      str(self.name),
    ])


class Sku(models.Model):

  store = models.ForeignKey(
    Store, on_delete=models.CASCADE, null=False, blank=False
  )

  tag = models.CharField(
    _('tag'), max_length=32, null=False, blank=False
  )

  name = models.CharField(
    _('name'), max_length=128, null=True, blank=True
  )

  length = models.FloatField(
    _('length'), null=True, blank=True
  )

  depth = models.FloatField(
    _('depth'), null=True, blank=True
  )

  height = models.FloatField(
    _('height'), null=True, blank=True
  )

  urvc = models.FloatField(
    _('unit cost price'), null=True, blank=True
  )

  urvn = models.FloatField(
    _('unit retail price'), null=True, blank=True
  )

  size = models.IntegerField(
    _('pack size'), null=True, blank=True
  )

  sfcols = models.IntegerField(
    _('shelf num cols'), null=True, blank=True
  )

  sfrows = models.IntegerField(
    _('shelf num rows'), null=True, blank=True
  )

  tpcols = models.IntegerField(
    _('top num cols'), null=True, blank=True
  )

  tprows = models.IntegerField(
    _('top num rows'), null=True, blank=True
  )

  bkcols = models.IntegerField(
    _('back num cols'), null=True, blank=True
  )

  bkrows = models.IntegerField(
    _('back num rows'), null=True, blank=True
  )

  ordays = ArrayField(
    models.IntegerField(), verbose_name=_('order receive days aka lead time'), null=True, blank=True
  )

  orprob = ArrayField(
    models.FloatField(), verbose_name=_('order receive days probability of each day'), null=True, blank=True
  )

  orpoos = models.FloatField(
    _('order receive out of stock probability'), null=True, blank=True
  )

  orgday = models.IntegerField(
    _('order receive regular day aka target days of units when order'), null=True, blank=True
  )

  orgprb = models.FloatField(
    _('order receive regular day aka target probability when order'), null=True, blank=True
  )

  orgvar = models.FloatField(
    _('order variable cost by unit volume'), null=True, blank=True
  )

  orgxrg = models.NullBooleanField(
    _('use express receive or not when order receive is desperate'), null=True, blank=True
  )

  xrdays = ArrayField(
    models.IntegerField(), verbose_name=_('express receive days aka lead time'), null=True, blank=True
  )

  xrprob = ArrayField(
    models.FloatField(), verbose_name=_('express receive days probability of each day'), null=True, blank=True
  )

  xrpoos = models.FloatField(
    _('express receive out of stock probability'), null=True, blank=True
  )

  xrgday = models.IntegerField(
    _('express receive regular day aka target days of units when express'), null=True, blank=True
  )

  xrgprb = models.FloatField(
    _('express receive regular day aka target probability when order'), null=True, blank=True
  )

  xrgvar = models.FloatField(
    _('express order variable cost by unit volume'), null=True, blank=True
  )

  asksmn = models.FloatField(
    _('daily demand mean'), null=True, blank=True
  )

  askssd = models.FloatField(
    _('daily demand standard deviation'), null=True, blank=True
  )

  @property
  def gtag(self):
    """sku group tag: in optimizer, sku is expanded to a group of skus w.r.t sfcols."""
    return self.tag.split('-')[0]

  @property
  def volume(self):
    """unit volume"""
    return self.length * self.depth * self.height

  @property
  def urvm(self):
    """unit revenue margin, aka gross profit."""
    return self.urvn - self.urvc

  class Meta:
    unique_together = (('store', 'tag'), )

  def __str__(self):
    return '|'.join([
      str(self.store),
      str(self.tag),
      str(self.name),
    ])


class Event(models.Model):

  ACTION_NN = 0
  ACTION_RC = 1
  ACTION_SC = 2
  ACTION_MV = 3
  ACTION_SL = 4
  ACTION_OR = 5
  ACTION_XR = 6
  ACTION_HD = 7

  ACTION_CHOICES = (
    (ACTION_NN, 'None'),
    (ACTION_RC, 'Receive'),
    (ACTION_SC, 'Scan'),
    (ACTION_MV, 'Move'),
    (ACTION_SL, 'Sell'),
    (ACTION_OR, 'Order'),
    (ACTION_XR, 'Express'),
    (ACTION_HD, 'Holding'),
  )

  STATUS_NN = 0
  STATUS_QU = 1
  STATUS_OK = 2
  STATUS_MS = 3
  STATUS_UN = 4

  STATUS_CHOICES = (
    (STATUS_NN, 'None'),
    (STATUS_QU, 'Queue'),
    (STATUS_OK, 'Ok'),
    (STATUS_MS, 'Miss'),
    (STATUS_UN, 'Unknown'),
  )

  SRCTRG_NN = 0
  SRCTRG_SF = 1
  SRCTRG_TP = 2
  SRCTRG_BK = 3

  SRCTGT_CHOICES = (
    (SRCTRG_NN, 'None'),
    (SRCTRG_SF, 'Shelf'),
    (SRCTRG_TP, 'Top'),
    (SRCTRG_BK, 'Back'),
  )

  sku = models.ForeignKey(
    Sku, on_delete=models.CASCADE, null=False, blank=False
  )

  day = models.IntegerField(
    null=True, blank=True
  )

  action = models.IntegerField(
    default=ACTION_NN, choices=ACTION_CHOICES, null=True, blank=True
  )

  source = models.IntegerField(
    default=SRCTRG_NN, choices=SRCTGT_CHOICES, null=True, blank=True
  )

  target = models.IntegerField(
    default=SRCTRG_NN, choices=SRCTGT_CHOICES, null=True, blank=True
  )

  units = models.IntegerField(
    default=0, null=True, blank=True
  )

  expense = models.FloatField(
    default=0.00, null=True, blank=True
  )

  revenue = models.FloatField(
    default=0.00, null=True, blank=True
  )

  status = models.IntegerField(
    default=STATUS_QU, choices=STATUS_CHOICES, null=True, blank=True
  )

  def __str__(self):
    return '|'.join([
      str(self.sku),
      str(self.day),
      str(self.action),
      str(self.source),
      str(self.target),
      str(self.units),
      str(self.expense),
      str(self.revenue),
      str(self.status),
    ])


class Ledger(models.Model):

  sku = models.ForeignKey(
    Sku, on_delete=models.CASCADE, null=False, blank=False
  )

  day = models.IntegerField(
    null=True, blank=True
  )

  ask = models.IntegerField(
    _('ask units'), null=True, blank=True
  )

  sfu = models.IntegerField(
    _('shelf units'), null=True, blank=True
  )

  sfx = models.IntegerField(
    _('shelf units receive'), null=True, blank=True
  )

  tpu = models.IntegerField(
    _('top units'), null=True, blank=True
  )

  tpx = models.IntegerField(
    _('top units receive'), null=True, blank=True
  )

  bku = models.IntegerField(
    _('back units'), null=True, blank=True
  )

  bkx = models.IntegerField(
    _('back units receive'), null=True, blank=True
  )

  # @property
  # run = models.IntegerField(
  #   _('receive units'), null=True, blank=True
  # )

  sun = models.IntegerField(
    _('sell units'), null=True, blank=True
  )

  oun = models.IntegerField(
    _('order units'), null=True, blank=True
  )

  xun = models.IntegerField(
    _('express units'), null=True, blank=True
  )

  rex = models.FloatField(
    _('receive expense'), null=True, blank=True
  )

  sex = models.FloatField(
    _('scan expense'), null=True, blank=True
  )

  mex = models.FloatField(
    _('move expense'), null=True, blank=True
  )

  oex = models.FloatField(
    _('order expense'), null=True, blank=True
  )

  xex = models.FloatField(
    _('express expense'), null=True, blank=True
  )

  cex = models.FloatField(
    _('holding w.r.t capital expense'), null=True, blank=True
  )

  vex = models.FloatField(
    _('holding w.r.t volumes expense'), null=True, blank=True
  )

  rvn = models.FloatField(
    _('revenue'), null=True, blank=True
  )

  rvc = models.FloatField(
    _('cost recognition w.r.t revenue'), null=True, blank=True
  )

  rvo = models.FloatField(
    _('revenue misse due oos'), null=True, blank=True
  )

  @property
  def tag(self):
    return self.sku.tag

  @property
  def name(self):
    return self.sku.name

  @property
  def sfcols(self):
    return self.sku.sfcols

  @property
  def sfrows(self):
    return self.sku.sfrows

  @property
  def length(self):
    return self.sku.sfcols * self.sku.length

  @property
  def depth(self):
    return self.sku.sfrows * self.sku.depth

  @property
  def height(self):
    return self.sku.height

  @property
  def urvc(self):
    return self.sku.urvc

  @property
  def urvn(self):
    return self.sku.urvn

  @property
  def urvm(self):
    return self.sku.urvm

  @property
  def sfv(self):
    """shelf capacity"""
    return self.sku.sfcols * self.sku.sfrows

  @property
  def sfw(self):
    """shelf available"""
    return self.sfv - self.sfu

  @property
  def sfp(self):
    """shelf packs receive, whole pack to shelf, if partial pack goes to top or back then top or back"""
    return self.sfx // self.sku.size

  @property
  def tpv(self):
    """top capacity"""
    return self.sku.tpcols * self.sku.tprows

  @property
  def tpw(self):
    """top available"""
    return self.tpv - self.tpu

  @property
  def tpp(self):
    """top packs receive, partial and whole pack to top, if partial pack goes to back then back"""
    return (self.sfx + self.tpx) // self.sku.size - self.sfp

  @property
  def bkv(self):
    """back capacity"""
    return self.sku.bkcols * self.sku.bkrows

  @property
  def bkw(self):
    """back available"""
    return self.bkv - self.bku

  @property
  def bkp(self):
    """back packs receive, partial and whole pack to back"""
    return self.smx / self.sku.size - self.sfp - self.tpp

  @property
  def smu(self):
    return self.sfu + self.tpu + self.bku

  @property
  def smv(self):
    return self.sfv + self.tpv + self.bkv

  @property
  def smw(self):
    return self.sfw + self.tpw + self.bkw

  @property
  def smx(self):
    """sum receive units, aka run"""
    return self.sfx + self.tpx + self.bkx

  @property
  def smp(self):
    return self.smx / self.sku.size

  @property
  def sfxsmx(self):
    """receive to shelf rate, by units."""
    return self.sfx / max(1, self.smx)

  @property
  def tpxsmx(self):
    """receive to top rate, by units."""
    return self.tpx / max(1, self.smx)

  @property
  def bkxsmx(self):
    """receive to back rate, by units."""
    return self.bkx / max(1, self.smx)

  @property
  def sfpsmp(self):
    """receive to shelf rate, by packs."""
    return self.sfp / max(1, self.smp)

  @property
  def tppsmp(self):
    """receive to top rate, by packs."""
    return self.tpp / max(1, self.smp)

  @property
  def bkpsmp(self):
    """receive to back rate, by packs."""
    return self.bkp / max(1, self.smp)

  @property
  def run(self):
    """sum receive units, aka smx"""
    return self.sfx + self.tpx + self.bkx

  @property
  def ounxun(self):
    """sum order express units"""
    return self.oun + self.xun

  @property
  def wex(self):
    """sum of expense over receive, scan, move, e.g., store labor cost."""
    return self.rex + self.sex + self.mex

  @property
  def zex(self):
    """sum of expense over receive, scan, move, order, express, and holding"""
    return self.rex + self.sex + self.mex + self.oex + self.xex + self.cex + self.vex

  @property
  def rvm(self):
    """revenue margin, aka gross profit"""
    return self.rvn - self.rvc

  @property
  def rvx(self):
    """revenue minus cost minus expense, net profit"""
    return self.rvn - self.rvc - self.zex

  class Meta:
    unique_together = (('sku', 'day'), )

  def __str__(self):
    return '|'.join([
      str(self.sku),
      str(self.day),
    ])


class Cache(models.Model):

  tag = models.CharField(
    _('tag'), max_length=32, null=False, blank=False
  )

  store = models.CharField(
    _('store'), max_length=32, null=False, blank=False
  )

  sku = models.CharField(
    _('sku'), max_length=32, null=True, blank=True
  )

  day = models.IntegerField(
    _('day'), null=True, blank=True
  )

  content = JSONField(
    _('content'), null=True, blank=True
  )

  class Meta:
    unique_together = (('tag', 'store', 'sku', 'day'), )

  def __str__(self):
    return '|'.join([
      str(self.tag),
      str(self.store),
      str(self.sku),
      str(self.day),
    ])

