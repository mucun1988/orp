from django.conf.urls import re_path, include

from rest_framework import routers
from .views import StoreViewSet, SkuViewSet, EventViewSet, LedgerViewSet, CacheViewSet
from .views import StoreLedgerOverviewAPIView
from .views import StoreLedgerSkuViewAPIView
from .views import StoreLedgerDayViewAPIView
from .views import SkuLedgerOverviewAPIView
from .views import SkuLedgerDayViewAPIView
from .views import TagStoreAPIView
from .views import TagStoreSkuAPIView

router = routers.DefaultRouter()
router.register(r'stores', StoreViewSet)
router.register(r'skus', SkuViewSet)
router.register(r'events', EventViewSet)
router.register(r'ledgers', LedgerViewSet)
router.register(r'caches', CacheViewSet)

app_name = 'backend'

urlpatterns = [
  re_path(r'^', include((router.urls, 'router'))),
  re_path(r'^store_ledger_overview/', StoreLedgerOverviewAPIView.as_view(), name='store-ledger-overview'),
  re_path(r'^store_ledger_sku_view/', StoreLedgerSkuViewAPIView.as_view(), name='store-ledger-sku-view'),
  re_path(r'^store_ledger_day_view/', StoreLedgerDayViewAPIView.as_view(), name='store-ledger-day-view'),
  re_path(r'^sku_ledger_overview/', SkuLedgerOverviewAPIView.as_view(), name='sku-ledger-overview'),
  re_path(r'^sku_ledger_day_view/', SkuLedgerDayViewAPIView.as_view(), name='sku-ledger-day-view'),
  re_path(r'^tag_store/', TagStoreAPIView.as_view(), name='tag-store'),
  re_path(r'^tag_store_sku/', TagStoreSkuAPIView.as_view(), name='tag-store-sku'),
]

