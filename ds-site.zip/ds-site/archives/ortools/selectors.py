"""selectors.py
Author: yg <gyang274@gmail.com>
"""

from ortools.linear_solver import pywraplp


def select_from_mixed_integer_solver(w, v, Wmin, Wmax, xmin, xmax):
  """Given: w_{ij}, and v_{ij}

  Solve: \max \sum_{ij} v_{ij} * b_{ij}

    s.t. \sum_{ij} w_{ij} * b_{ij} >= Wmin
         \sum_{ij} w_{ij} * b_{ij} <= Wmax
         \sum_j b_{ij} >= xmin \any i
         \sum_j b_{ij} <= xmax \any i
         b_{ij} \in (0, 1)
  """

  solver = pywraplp.Solver(
    'SolveMIP', pywraplp.Solver.CBC_MIXED_INTEGER_PROGRAMMING
  )

  # b_{ij}, s.t., b_{ij} \in (0, 1)
  # b = [
  #   [
  #     solver.IntVar(
  #       0.0, 1.0, 'b-' + str(i) + '-' + str(j)
  #     ) for j, wij in enumerate(wi)
  #   ] for i, wi in enumerate(w)
  # ]
  # 2018.08.22: bug when use (0, 1)
  # solver returns non-optimium results as optimium reached
  # relaxed condition is ok as the condition on sum guarded
  b = [
    [
      solver.IntVar(
        0.0, solver.infinity(), 'b-' + str(i) + '-' + str(j)
      ) for j, wij in enumerate(wi)
    ] for i, wi in enumerate(w)
  ]

  # \sum_j b_{ij} >= xmin \any i
  # \sum_j b_{ij} <= xmax \any i
  for i, bi in enumerate(b):
    exec(f'constraint_{i} = solver.Constraint(xmin, xmax)')
    for j, bij in enumerate(bi):
      exec(f'constraint_{i}.SetCoefficient(b[{i}][{j}], 1)')

  # \sum_{ij} w_{ij} * b_{ij} >= Wmin
  # \sum_{ij} w_{ij} * b_{ij} <= Wmax
  Wmin = Wmin or -solver.infinity()
  Wmax = Wmax or  solver.infinity()
  constraint_w = solver.Constraint(Wmin, Wmax)
  for i, bi in enumerate(b):
    for j, bij in enumerate(bi):
      exec(f'constraint_w.SetCoefficient(b[{i}][{j}], w[{i}][{j}])')

  # \max \sum_{ij} v_{ij} * b_{ij}
  objective = solver.Objective()
  for i, bi in enumerate(b):
    for j, bij in enumerate(bi):
      exec(f'objective.SetCoefficient(b[{i}][{j}], v[{i}][{j}])')
  objective.SetMaximization()

  # solve the problem and print the solution.
  result_status = solver.Solve()
  # check the problem has an optimal solution.
  assert result_status == pywraplp.Solver.OPTIMAL

  # The solution looks legit (when using solvers other than
  # GLOP_LINEAR_PROGRAMMING, verifying the solution is highly recommended!).
  assert solver.VerifySolution(1e-7, True)

  print('Number of variables: ', solver.NumVariables())
  print('Number of constraints: ', solver.NumConstraints())

  # The objective value of the solution.
  print('Optimal objective value: ', solver.Objective().Value())

  # The value of each variable in the solution.
  for i, bi in enumerate(b):
    for j, bij in enumerate(bi):
      print('{}: {}'.format(bij.name(), bij.solution_value()))

  # solution w.r.t w, v
  s = [
    [
      bij.solution_value(
      ) for j, bij in enumerate(bi)
    ] for i, bi in enumerate(b)
  ]

  return s


if __name__ == '__main__':
  w = [[1.1, 2.2, 3.4], [1.2, 2.3]]
  v = [[2.4, 4.6, 7.2], [2.3, 4.8]]
  Wmin = 0.0
  Wmax = 3.7
  xmin = 1.0
  xmax = 1.0
  b = select_from_mixed_integer_solver(w, v, Wmin, Wmax, xmin, xmax)

