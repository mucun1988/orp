#!/usr/bin/env bash

# run from @ds-site

sudo -u postgres psql -c "DROP DATABASE ds_site;"

sudo -u postgres psql -c "CREATE DATABASE ds_site;"

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ds_site TO yg;"

rm backend/migrations/000*.py

python manage.py makemigrations

python manage.py migrate

#python manage.py init_ledger

