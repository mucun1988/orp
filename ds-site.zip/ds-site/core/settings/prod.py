from .base import *

DATABASES = {
  'default': {
    'ENGINE': 'django.db.backends.postgresql',
    'NAME': 'ds_site',
    'USER': 'isiteadmin',
    'PASSWORD': 'i0422@GPU',
    'HOST': '127.0.0.1',
    'PORT': '5432',
  }
}

STATIC_ROOT = os.path.join(BASE_DIR, 'dist/static')
